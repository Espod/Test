'use strict'
module.exports = {
  NODE_ENV: '"production"',
  // BASE_API: '"http://99.6.152.5:8092"',
  BASE_API: '"http://127.0.0.1:8092"',
}
