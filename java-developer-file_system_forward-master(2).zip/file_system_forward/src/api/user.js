import request from '@/utils/request'

export function modifyPassword(oldPassword, password) {
  return request({
    url: '/auth/token/manager/modify/password',
    method: 'post',
    data: {
      oldPassword,
      password
    }
  })
}
