import request from '@/utils/request'
// 展示目录
export function showCatalog(parentId) {
  return request({
    url: '/auth/token/file/showCatalog',
    method: 'post',
    data: {
      parentId
    }
  })
}

// 展示客户端目录
export function showClientCatalog(parentId) {
  return request({
    url: '/auth/white/client/showCatalog',
    method: 'post',
    data: {
      parentId
    }
  })
}

// 新建文件夹
export function createDirectory(parentId, fileName) {
  return request({
    url: '/auth/token/file/createDirectory',
    method: 'post',
    data: {
      parentId,
      fileName
    }
  })
}

export function updateName(id, fileName) {
  return request({
    url: '/auth/token/file/updateName',
    method: 'post',
    data: {
      id,
      fileName
    }
  })
}
// 删除文件（夹）
export function deleteFile(id) {
  return request({
    url: '/auth/token/file/delete/' + id,
    method: 'post'
  })
}

// 批量删除文件（夹）
export function batchDeleteFile(ids) {
  return request({
    url: '/auth/token/file/deleteBatch/' + ids,
    method: 'post'
  })
}

// 创建白名单
export function createWhiteList(ipAddress, catalogId) {
  return request({
    url: '/auth/token/whiteList/create',
    method: 'post',
    data: {
      ipAddress,
      catalogId
    }
  })
}

// 修改白名单
export function updateWhiteList(ipAddress, catalogId) {
  return request({
    url: '/auth/token/whiteList/update',
    method: 'post',
    data: {
      ipAddress,
      catalogId
    }
  })
}

// 删除白名单
export function deleteWhiteList(catalogId) {
  return request({
    url: '/auth/token/whiteList/delete/' + catalogId,
    method: 'post'
  })
}

export function test() {
  return request({
    url: '/auth/test',
    method: 'post'
  })
}
