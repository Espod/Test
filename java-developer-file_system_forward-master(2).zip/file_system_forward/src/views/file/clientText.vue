<template>
  <div class="app-container">
    <div class="head">
      <el-breadcrumb class="app-breadcrumb" separator="/">
        <transition-group name="breadcrumb">
          <el-breadcrumb-item v-for="(item,key,index) in levelList" :key="key">
            <span v-if="index==levelList.length-1" class="no-redirect">{{ item.fileName }}</span>
            <a v-else @click.prevent="handleLink(item, key)">{{ item.fileName }}</a>
          </el-breadcrumb-item>
        </transition-group>
      </el-breadcrumb>
    </div>
    <div class="body">
      <div class="title">
        <el-row type="flex" align="middle">
          <el-col>
            <strong>文件名</strong>
          </el-col>
          <el-col>
            <strong>修改时间</strong>
          </el-col>
          <el-col>
            <strong>文件大小</strong>
          </el-col>
        </el-row>
        <el-row v-for="(item,index) in list" :key="index" type="flex" align="middle">
          <el-col>
            <el-button type="text" @click="fileClickMethod(item)">
              <svg-icon :icon-class="item.fileIcon" />
              <el-tooltip :disabled="item.tipDisabled" :content="item.fileNameStr" placement="bottom" effect="light">
                <span>{{ item.fileName }}</span>
              </el-tooltip>
            </el-button>
          </el-col>
          <el-col>
            {{ item.updateTime }}
          </el-col>
          <el-col>
            <span v-if="item.isDirectory == 0">{{ item.fileSize }}KB</span>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>

<script>
import { showClientCatalog } from '@/api/file'
import { getFileIconName } from '@/utils/file'

export default {
  data() {
    return {
      levelList: [// 面包屑导航栏
        {
          fileName: '文件管理',
          id: null,
          parentId: null
        }
      ],
      listLoading: false, // 页面加载旋转图标
      list: null, // 从后台获取的当前目录列表
      parentId: null // 当前页面的父级id
    }
  },
  // 页面初始化
  created() {
    this.initialFiles()
  },
  methods: {
    // 页面初始化数据
    initialFiles() {
      // 初始化数据
      this.showCatalog(null)
    },
    // 查询目录信息
    showCatalog(parentId) {
      this.listLoading = true
      this.parentId = parentId
      showClientCatalog(parentId).then(response => {
        if (response.code !== 'SUCCESS') {
          this.$message({
            type: 'error',
            message: response.message
          })
        } else {
          this.list = response.data
          if (this.list != null) {
            for (var i = 0; i < this.list.length; i++) {
              const fileItem = this.list[i]
              fileItem.fileNameStr = fileItem.fileName
              if (fileItem.fileName.length > 30) {
                fileItem.fileName = fileItem.fileName.substring(0, 30) + '...'
                fileItem.tipDisabled = false
              } else {
                fileItem.tipDisabled = true
              }
              if (fileItem.isDirectory === 1) {
                fileItem.fileIcon = 'directory'
              } else {
                fileItem.fileIcon = getFileIconName(fileItem.fileType)
              }
            }
          }
        }
      })
      this.listLoading = false
    },
    // 展示子目录，单击文件夹时调用的
    showChildrenCatalog(file) {
      this.levelList.push(file)
      this.showCatalog(file.id)
    },
    // 面包屑导航点击
    handleLink(file, index) {
      // 面包屑导航点击，先将当前点击元素后的所有元素清空掉，再展示当前目录
      var removeLength = this.levelList.length - index
      this.levelList.splice(index + 1, removeLength)
      this.showCatalog(file.id)
    },
    // 单击目录时调用（若是文件夹，则显示下一层；反之，则下载当前文件）
    fileClickMethod(file) {
      if (file.isDirectory === 1) {
        // 文件夹的话，则展示下层目录
        this.showChildrenCatalog(file)
      } else {
        // 文件则点击下载
        this.downloadFile(file)
      }
    },
    // 下载文件
    downloadFile(file) {
      let url = process.env.BASE_API + '/auth/white/client/download?'
      url += 'fileType=' + file.fileType + '&downLoadId=' + file.downLoadId
      url += '&fileId=' + file.id
      window.location.href = url
    }
  }
}
</script>

<style scoped>
.line{
  text-align: center;
}
.head{
  margin-top: 20px;
  margin-bottom: 20px;
}
</style>

