<template>
  <div class="app-container">
    <div class="title">
      <el-row type="flex">
        <el-col>
          <el-row type="flex">
            <el-col>
              <el-dropdown @command="handleCommand">
                <el-button>
                  <svg-icon icon-class="upload" />
                  上传<i class="el-icon-arrow-down el-icon--right"/>
                </el-button>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item command="file">文件上传</el-dropdown-item>
                  <el-dropdown-item command="directory">文件夹上传</el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </el-col>
            <el-col>
              <el-button @click="batchDownload">
                <svg-icon icon-class="download" />
                <span>打包下载</span>
              </el-button>
            </el-col>
            <el-col>
              <el-button :disabled="directoryButtonDisable" @click="createDirectory">
                <svg-icon icon-class="createDirectory" />
                <span>新建文件夹</span>
              </el-button>
            </el-col>
            <el-col>
              <el-button @click="batchDeleteFile">
                <svg-icon icon-class="delete" />
                删除
              </el-button>
            </el-col>
          </el-row>

        </el-col>
        <el-col/>

      </el-row>

    </div>
    <div class="head">
      <el-breadcrumb class="app-breadcrumb" separator="/">
        <transition-group name="breadcrumb">
          <el-breadcrumb-item v-for="(item,key,index) in levelList" :key="key">
            <span v-if="index==levelList.length-1" class="no-redirect">{{ item.fileName }}</span>
            <a v-else @click.prevent="handleLink(item, key)">{{ item.fileName }}</a>
          </el-breadcrumb-item>
        </transition-group>
      </el-breadcrumb>
    </div>
    <div class="body">
      <el-table
        v-loading="listLoading"
        :data="list"
        element-loading-text="Loading"
        fit
        mini
        highlight-current-row
        @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55"/>
        <el-table-column label="文件名" width="400">
          <template slot-scope="scope">
            <div @mouseover="showOperate(scope.row)" @mouseout="hideOperate(scope.row)">
              <el-row type="flex" justify="space-between" align="middle" >
                <el-col>
                  <el-button v-if="scope.row.showInput" type="text">
                    <svg-icon :icon-class="scope.row.fileIcon" />
                    <el-input v-focus="scope.row.showInput" v-model="scope.row.fileNameStr" @keyup.enter.native="directoryBlur(scope.row)"/>
                  </el-button>
                  <el-button v-else type="text" @click="fileClickMethod(scope.row)">
                    <svg-icon :icon-class="scope.row.fileIcon" />
                    <el-tooltip :disabled="scope.row.tipDisabled" :content="scope.row.fileNameStr" placement="bottom" effect="light">
                      <span>{{ scope.row.fileName }}</span>
                    </el-tooltip>
                  </el-button>
                </el-col>
                <el-col>
                  <div v-show="scope.row.mouseOperate">
                    <el-button type="primary" size="mini" icon="el-icon-edit" circle @click="preUpdateName(scope.row)"/>
                    <el-button type="danger" size="mini" icon="el-icon-delete" circle @click="deleteFile(scope.row.id)"/>
                  </div>
                </el-col>
              </el-row>
            </div>

          </template>
        </el-table-column>
        <el-table-column label="修改时间">
          <template slot-scope="scope">
            {{ scope.row.updateTime }}
          </template>
        </el-table-column>
        <el-table-column label="文件大小">
          <template slot-scope="scope">
            <span v-if="scope.row.isDirectory == 0">{{ scope.row.fileSize }}KB</span>
          </template>
        </el-table-column>
        <el-table-column label="白名单">
          <template slot-scope="scope">
            {{ scope.row.whiteListStr }}
          </template>
        </el-table-column>
        <el-table-column label="白名单操作">
          <template slot-scope="scope">
            <el-button type="primary" size="mini" circle @click="showCreateDialog(scope.row)">
              <svg-icon icon-class="create" />
            </el-button>
            <el-button type="primary" size="mini" icon="el-icon-edit" circle @click="showUpdateDialog(scope.row)" />
            <el-button type="danger" size="mini" icon="el-icon-delete" circle @click="deleteWhiteList(scope.row.id)" />
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="footer">
      <el-dialog :visible.sync="dialogFormVisible" :title="dialogTitle">
        <el-form :model="form">
          <el-form-item :label-width="formLabelWidth" label="白名单">
            <el-input v-model="form.whiteList" type="textarea" autocomplete="off" placeholder="请输入白名单信息，多个用'逗号'隔开" @keyup.enter.native="operateWhiteList"/>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button :disabled="dialogFormVisibleDisable" type="primary" @click="operateWhiteList">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <div class="uploadFooter">
      <el-dialog :visible.sync="uploadDialogFormVisible" title="批量上传">
        <el-upload
          ref="upload"
          :auto-upload="false"
          :action="uploadUrl"
          :headers="Headers"
          :on-success="uploadSuccess"
          :data="dataObj"
          :file-list="uploadFileList"
          multiple>
          <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
        </el-upload>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="submitUpload" >提交上传</el-button>
        </div>
      </el-dialog>
    </div>
    <div class="uploadDirectoryFooter">
      <el-dialog :visible.sync="uploadDirectoryDialogFormVisible" title="上传文件夹">
        <form>
          <div class="fileCss">选择文件
            <input ref="uploadDirectoryRef" type="file" webkitdirectory @change="getFile($event)">
          </div>
          <p>文件夹中共有：{{ uploadDirectoryFileList.length }}个文件</p>
        </form>
        <el-progress v-show="progress.isShow" :percentage="progress.percentage" :status="progress.status"/>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" @click="submitUploadDirectory" >提交上传</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import { showCatalog, createDirectory, updateName, deleteFile, batchDeleteFile,
  createWhiteList, updateWhiteList, deleteWhiteList } from '@/api/file'
import { getToken } from '@/utils/auth'
import { getFileIconName } from '@/utils/file'
import axios from 'axios'

export default {
  directives: {
    'focus': {
      inserted: function(el) {
        el.querySelector('input').focus()
      }
    }
  },
  data() {
    return {
      levelList: [// 面包屑导航栏
        {
          fileName: '文件管理',
          id: null,
          parentId: null
        }
      ],
      listLoading: true, // 页面加载旋转图标
      list: null, // 从后台获取的当前目录列表
      directoryButtonDisable: false, // 新建文件夹的按钮启用禁用设置
      parentId: null, // 当前页面的父级id
      uploadUrl: process.env.BASE_API + '/auth/token/file/upload',
      dataObj: {// 上传文件时所需的额外数据
        parentId: null
      },
      Headers: {
        'X-Token': getToken() // 上传文件时设置的header
      },
      multipleSelection: [], // 保存checkbox选中的数据
      dialogFormVisible: false, // 用来显示隐藏模态框的
      form: {
        whiteList: ''
      },
      formLabelWidth: '120px', // 模态框宽度
      dialogTitle: null, // 模态框标题
      whiteListOperate: {
        operate: null, // 用来标记模态框到底是要新增还是要修改的
        file: null // 白名单操作时对应的文件
      },
      uploadDialogFormVisible: false, // 用来显示隐藏批量上传模态框的
      uploadFileList: [],
      batchUploadUrl: process.env.BASE_API + '/auth/token/file/batchUpload',
      dialogFormVisibleDisable: false, // 白名单弹框禁用
      uploadDirectoryDialogFormVisible: false, // 上传文件夹模态框隐藏
      uploadDirectoryFileList: [],
      progress: {
        percentage: 0,
        status: null,
        isShow: false
      }
    }
  },
  // 页面初始化
  created() {
    this.initialFiles()
  },
  methods: {
    // 页面初始化数据
    initialFiles() {
      // 初始化数据
      this.showCatalog(null)
    },
    // 查询目录信息
    showCatalog(parentId) {
      this.listLoading = true
      this.parentId = parentId
      this.dataObj.parentId = parentId == null ? 0 : parentId
      showCatalog(parentId).then(response => {
        if (response.code !== 'SUCCESS') {
          this.$message({
            type: 'error',
            message: response.message
          })
        } else {
          this.list = response.data
          if (this.list != null) {
            for (var i = 0; i < this.list.length; i++) {
              const fileItem = this.list[i]
              fileItem.fileNameStr = fileItem.fileName
              if (fileItem.fileName.length > 20) {
                fileItem.fileName = fileItem.fileName.substring(0, 20) + '...'
                fileItem.tipDisabled = false
              } else {
                fileItem.tipDisabled = true
              }
              if (fileItem.isDirectory === 1) {
                fileItem.fileIcon = 'directory'
              } else {
                fileItem.fileIcon = getFileIconName(fileItem.fileType)
              }
              if (fileItem.whiteList != null) {
                let whiteListStr = ''
                for (var j = 0; j < fileItem.whiteList.length; j++) {
                  whiteListStr += fileItem.whiteList[j].ipAddress + ','
                }
                this.list[i].whiteListStr = whiteListStr.substring(0, whiteListStr.length - 1)
              }
            }
          }
        }
        this.listLoading = false
      })
    },
    // 创建文件夹
    createDirectory() {
      this.directoryButtonDisable = true
      const testData = {
        fileNameStr: '新建文件夹',
        createTime: null,
        whiteList: null,
        showInput: true,
        fileIcon: 'directory',
        id: null
      }
      this.list.unshift(testData)
    },
    // 创建文件夹时，修改文件夹名称的input标签失去焦点时的操作
    directoryBlur(file) {
      this.listLoading = true
      if (file.id == null) {
        // 输入框失去焦点后调用新建文件夹接口
        createDirectory(this.parentId, file.fileNameStr).then(response => {
          if (response.code !== 'SUCCESS') {
            this.$message({
              type: 'error',
              message: response.message
            })
          } else {
            this.showCatalog(this.parentId)
          }
          this.directoryButtonDisable = false
          this.listLoading = false
        })
      } else {
        updateName(file.id, file.fileNameStr).then(response => {
          if (response.code !== 'SUCCESS') {
            this.$message({
              type: 'error',
              message: response.message
            })
          } else {
            this.showCatalog(this.parentId)
          }
          this.listLoading = false
        })
      }
    },
    // 展示子目录，单击文件夹时调用的
    showChildrenCatalog(file) {
      this.levelList.push(file)
      this.showCatalog(file.id)
    },
    // 面包屑导航点击
    handleLink(file, index) {
      // 面包屑导航点击，先将当前点击元素后的所有元素清空掉，再展示当前目录
      var removeLength = this.levelList.length - index
      this.levelList.splice(index + 1, removeLength)
      this.showCatalog(file.id)
    },
    // 显示目录的修改、删除操作按钮
    showOperate(file) {
      // 当前在文件input标签显示的时候，不展示按钮
      if (file.showInput) {
        return false
      }
      // 很奇葩的问题，如果只写mouseOperate=true的话，页面的按钮不会显示，下面这种写法就能显示
      const fileName = file.fileName
      file.fileName = '&^%*($'
      file.mouseOperate = true
      file.fileName = fileName
    },
    // 隐藏目录的修改、删除操作按钮
    hideOperate(file) {
      const fileName = file.fileName
      file.fileName = '&^%*($'
      file.mouseOperate = false
      file.fileName = fileName
    },
    // 修改文件（夹）时，显示输入框
    preUpdateName(file) {
      file.showInput = true
    },
    // 删除文件（夹）
    deleteFile(id) {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.listLoading = true
        deleteFile(id).then(response => {
          if (response.code !== 'SUCCESS') {
            this.$message({
              type: 'error',
              message: response.message
            })
          } else {
            this.showCatalog(this.parentId)
          }
          this.listLoading = false
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消'
        })
      })
    },
    // 单击目录时调用（若是文件夹，则显示下一层；反之，则下载当前文件）
    fileClickMethod(file) {
      if (file.isDirectory === 1) {
        // 文件夹的话，则展示下层目录
        this.showChildrenCatalog(file)
      } else {
        // 文件则点击下载
        this.downloadFile(file)
      }
    },
    // 上传文件成功后调用
    uploadSuccess(response, file, fileList) {
      const code = response.code
      if (code !== 'SUCCESS') {
        this.$message({
          type: 'error',
          message: response.message
        })
      } else {
        this.$message({
          type: 'success',
          message: '上传成功'
        })
        // this.uploadDialogFormVisible = false
        this.showCatalog(this.parentId)
      }
    },
    // 上传文件出现异常时调用
    uploadError(response, file, fileList) {
      console.log('上传失败，请重试！', response)
    },
    // 多选框操作
    handleSelectionChange(val) {
      // val 为选中数据的集合
      this.multipleSelection = val
    },
    // 下载文件
    downloadFile(file) {
      let url = process.env.BASE_API + '/auth/token/file/download?'
      url += 'fileType=' + file.fileType + '&downLoadId=' + file.downLoadId
      url += '&X-Token=' + getToken()
      window.location.href = url
    },
    // 打包下载文件（夹）
    batchDownload() {
      if (this.multipleSelection.length === 0) {
        this.$message({
          type: 'error',
          message: '请选择文件'
        })
      } else {
        let parentIds = ''
        for (var i = 0; i < this.multipleSelection.length; i++) {
          var file = this.multipleSelection[i]
          parentIds += file.id + ','
        }
        parentIds = parentIds.substring(0, parentIds.length - 1)
        let url = process.env.BASE_API + '/auth/token/file/download/package?'
        url += 'parentIds=' + parentIds
        url += '&X-Token=' + getToken()
        window.location.href = url
      }
    },
    // 批量删除文件(夹)
    batchDeleteFile() {
      if (this.multipleSelection.length === 0) {
        this.$message({
          type: 'error',
          message: '请选择文件（夹）'
        })
      } else {
        this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.listLoading = true
          var ids = ''
          for (var i = 0; i < this.multipleSelection.length; i++) {
            var file = this.multipleSelection[i]
            ids += file.id + ','
          }
          batchDeleteFile(ids.substring(0, ids.length - 1)).then(response => {
            if (response.code !== 'SUCCESS') {
              this.$message({
                type: 'error',
                message: response.message
              })
            } else {
              this.showCatalog(this.parentId)
            }
            this.listLoading = false
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消'
          })
        })
      }
    },
    // 显示新增模态框
    showCreateDialog(file) {
      this.whiteListOperate.operate = 'create'
      this.whiteListOperate.file = file
      this.form.whiteList = null
      this.dialogTitle = '新增白名单'
      this.dialogFormVisible = true
      this.dialogFormVisibleDisable = false
    },
    // 显示修改模态框
    showUpdateDialog(file) {
      this.whiteListOperate.operate = 'update'
      this.whiteListOperate.file = file
      this.form.whiteList = this.whiteListOperate.file.whiteListStr
      this.dialogTitle = '修改白名单'
      this.dialogFormVisible = true
      this.dialogFormVisibleDisable = false
    },
    operateWhiteList() {
      if (this.form.whiteList === null) {
        this.$message({
          type: 'error',
          message: '请输入白名单信息'
        })
      } else {
        this.dialogFormVisibleDisable = true
        this.listLoading = true
        if (this.whiteListOperate.operate === 'create') {
          this.createWhiteList(this.form.whiteList, this.whiteListOperate.file.id)
        } else {
          this.updateWhiteList(this.form.whiteList, this.whiteListOperate.file.id)
        }
      }
    },
    // 创建白名单
    createWhiteList(ipAddress, catalogId) {
      createWhiteList(ipAddress, catalogId).then(response => {
        if (response.code !== 'SUCCESS') {
          this.$message({
            type: 'error',
            message: response.message
          })
          this.dialogFormVisibleDisable = false
        } else {
          this.dialogFormVisible = false
          this.showCatalog(this.parentId)
        }
        this.listLoading = false
      })
    },
    // 修改白名单
    updateWhiteList(ipAddress, catalogId) {
      updateWhiteList(ipAddress, catalogId).then(response => {
        if (response.code !== 'SUCCESS') {
          this.$message({
            type: 'error',
            message: response.message
          })
          this.dialogFormVisibleDisable = false
        } else {
          this.dialogFormVisible = false
          this.showCatalog(this.parentId)
        }
        this.listLoading = false
      })
    },
    // 删除白名单
    deleteWhiteList(catalogId) {
      this.$confirm('确认删除?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        this.listLoading = true
        deleteWhiteList(catalogId).then(response => {
          if (response.code !== 'SUCCESS') {
            this.$message({
              type: 'error',
              message: response.message
            })
          } else {
            this.showCatalog(this.parentId)
          }
          this.listLoading = false
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消'
        })
      })
    },
    submitUpload() {
      this.$refs.upload.submit()
    },
    showBatchUpload() {
      this.uploadFileList = []
      this.uploadDialogFormVisible = true
    },
    showBatchUploadDirectory() {
      this.progress.status = null
      this.progress.isShow = false
      this.uploadDirectoryFileList = []
      this.uploadDirectoryDialogFormVisible = true
      if (this.$refs.uploadDirectoryRef !== undefined) {
        this.$refs.uploadDirectoryRef.value = ''
      }
    },
    getFile(event) {
      this.uploadDirectoryFileList = event.target.files
    },
    submitUploadDirectory(event) {
      if (this.uploadDirectoryFileList.length === 0) {
        this.$message({
          type: 'error',
          message: '请选择文件夹'
        })
        return false
      }
      event.preventDefault()
      const formData = new FormData()
      for (var i = 0; i < this.uploadDirectoryFileList.length; i++) {
        formData.append('file', this.uploadDirectoryFileList[i])
      }
      formData.append('parentId', this.parentId == null ? 0 : this.parentId)

      const config = {
        headers: {
          'Content-Type': 'multipart/form-data',
          'X-Token': getToken()
        },
        onUploadProgress: ProgressEvent => {
          this.progress.isShow = true
          let persent = (ProgressEvent.loaded / ProgressEvent.total) * 100
          persent = parseInt(persent)
          if (persent === 100) {
            persent = 99
          }
          this.progress.percentage = persent
        }
      }
      axios.post(this.batchUploadUrl, formData, config).then((response) => {
        var data = response.data
        if (data.code !== 'SUCCESS') {
          this.$message({
            type: 'error',
            message: data.message
          })
        } else {
          this.$message({
            type: 'success',
            message: '上传成功'
          })
          this.progress.percentage = 100
          this.progress.status = 'success'
          this.showCatalog(this.parentId)
          this.uploadDirectoryDialogFormVisible = false
        }
        this.$refs.uploadDirectoryRef.value = ''
      })
    },
    handleCommand(command) {
      if (command === 'file') {
        this.showBatchUpload()
      } else {
        this.showBatchUploadDirectory()
      }
    }
  }
}
</script>

<style scoped>
.line{
  text-align: center;
}
.head{
  margin-top: 20px;
  margin-bottom: 20px;
}
.inputfile {
  width: 0.1px;
  height: 0.1px;
  opacity: 0;
  overflow: hidden;
  position: absolute;
  z-index: -1;
}
.el-dropdown {
  vertical-align: top;
}
.el-dropdown + .el-dropdown {
  margin-left: 15px;
}
.el-icon-arrow-down {
  font-size: 12px;
}

.fileCss {
    position: relative;
    display: inline-block;
    background: rgb(51, 153, 255);
    border: 1px solid rgb(51, 153, 255);
    border-radius: 4px;
    padding: 4px 12px;
    overflow: hidden;
    color: white;
    text-decoration: none;
    text-indent: 0;
    line-height: 20px;
}
.fileCss input {
    position: absolute;
    font-size: 100px;
    right: 0;
    top: 0;
    opacity: 0;
}
.fileCss:hover {
    background: rgb(102, 176, 245);
    border-color: rgb(102, 176, 245);
}

</style>

