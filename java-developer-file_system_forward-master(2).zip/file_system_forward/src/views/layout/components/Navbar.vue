<template>
  <div>
    <div class="header">
      <el-menu class="navbar" mode="horizontal">
        <hamburger :toggle-click="toggleSideBar" :is-active="sidebar.opened" class="hamburger-container"/>
        <breadcrumb />
        <el-dropdown class="avatar-container" trigger="click">
          <div class="avatar-wrapper">
            <svg-icon icon-class="manager" style="width:35px;height:35px" />
            <i class="el-icon-caret-bottom"/>
          </div>
          <el-dropdown-menu slot="dropdown" class="user-dropdown">
            <router-link class="inlineBlock" to="/">
              <el-dropdown-item>
                首页
              </el-dropdown-item>
            </router-link>
            <el-dropdown-item divided>
              <span style="display:block;" @click="preUpdatePassword">修改密码</span>
            </el-dropdown-item>
            <el-dropdown-item divided>
              <span style="display:block;" @click="logout">退出</span>
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>

      </el-menu>
    </div>
    <div>
      <el-dialog :visible.sync="dialogFormVisible" title="修改密码">
        <el-form :model="form">
          <el-form-item :label-width="formLabelWidth" label="原密码：">
            <el-input v-model="form.oldPassword" type="password" autocomplete="off" placeholder="请输入原密码" @keyup.enter.native="operateWhiteList"/>
          </el-form-item>
          <el-form-item :label-width="formLabelWidth" label="新密码：">
            <el-input v-model="form.newPassword1" type="password" autocomplete="off" placeholder="请输入新密码" @keyup.enter.native="operateWhiteList"/>
          </el-form-item>
          <el-form-item :label-width="formLabelWidth" label="确认密码：">
            <el-input v-model="form.newPassword2" type="password" autocomplete="off" placeholder="请再次确认新密码" @keyup.enter.native="operateWhiteList"/>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="updatePassword">确 定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Breadcrumb from '@/components/Breadcrumb'
import Hamburger from '@/components/Hamburger'
import { modifyPassword } from '@/api/user'
import { MessageBox } from 'element-ui'
import store from '@/store'

export default {
  components: {
    Breadcrumb,
    Hamburger
  },
  data() {
    return {
      dialogFormVisible: false, // 用来显示隐藏模态框的
      form: {
        oldPassword: '',
        newPassword1: '',
        newPassword2: ''
      },
      formLabelWidth: '120px', // 模态框宽度
      dialogTitle: null // 模态框标题
    }
  },
  computed: {
    ...mapGetters([
      'sidebar'
    ])
  },
  methods: {
    toggleSideBar() {
      this.$store.dispatch('ToggleSideBar')
    },
    logout() {
      this.$store.dispatch('FedLogOut').then(() => {
        location.reload() // 为了重新实例化vue-router对象 避免bug
      })
    },
    preUpdatePassword() {
      this.dialogFormVisible = true
    },
    updatePassword() {
      if (this.form.oldPassword === '') {
        this.$message({
          type: 'error',
          message: '请输入原密码'
        })
        return false
      }
      if (this.form.newPassword1 === '') {
        this.$message({
          type: 'error',
          message: '请输入新密码'
        })
        return false
      }
      if (this.form.newPassword1 === '') {
        this.$message({
          type: 'error',
          message: '请输入确认密码'
        })
        return false
      }
      if (this.form.newPassword1 !== this.form.newPassword2) {
        this.$message({
          type: 'error',
          message: '新密码和确认密码不一致'
        })
        return false
      }
      // TODO:修改密码
      modifyPassword(this.form.oldPassword, this.form.newPassword1).then(response => {
        MessageBox.confirm(
          '您已成功修改密码，可以取消继续留在该页面，或者重新登录',
          '确定登出',
          {
            confirmButtonText: '重新登录',
            cancelButtonText: '取消',
            type: 'warning'
          }
        ).then(() => {
          store.dispatch('FedLogOut').then(() => {
            location.reload() // 为了重新实例化vue-router对象 避免bug
          })
        })
      })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
.navbar {
  height: 50px;
  line-height: 50px;
  border-radius: 0px !important;
  .hamburger-container {
    line-height: 58px;
    height: 50px;
    float: left;
    padding: 0 10px;
  }
  .screenfull {
    position: absolute;
    right: 90px;
    top: 16px;
    color: red;
  }
  .avatar-container {
    height: 50px;
    display: inline-block;
    position: absolute;
    right: 35px;
    .avatar-wrapper {
      cursor: pointer;
      margin-top: 5px;
      position: relative;
      line-height: initial;
      .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 10px;
      }
      .el-icon-caret-bottom {
        position: absolute;
        right: -20px;
        top: 25px;
        font-size: 12px;
      }
    }
  }
}
</style>

