// 获取文件格式图标
export function getFileIconName(fileType) {
  let fileIcon
  switch (fileType) {
    case 'rar':
    case '7z':
    case 'zip':
      fileIcon = 'rar'
      break
    case 'docx':
    case 'doc':
      fileIcon = 'word'
      break
    case 'txt':
      fileIcon = 'txt'
      break
    case 'xls':
    case 'xlsx':
      fileIcon = 'xls'
      break
    case 'exe':
    case 'msi':
      fileIcon = 'exe'
      break
    case 'ppt':
      fileIcon = 'ppt'
      break
    case 'jar':
    case 'war':
      fileIcon = 'jar'
      break
    case 'pdf':
      fileIcon = 'pdf'
      break
    default:
      fileIcon = 'unknown'
  }
  return fileIcon
}
