/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1
Source Server Version : 80013
Source Host           : 127.0.0.1:3306
Source Database       : file_system

Target Server Type    : MYSQL
Target Server Version : 80013
File Encoding         : 65001

Date: 2018-12-14 16:50:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for fs_file_info
-- ----------------------------
DROP TABLE IF EXISTS `fs_file_info`;
CREATE TABLE `fs_file_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(60) NOT NULL COMMENT '文件名称',
  `file_type` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '文件类型（文件后缀名）',
  `is_directory` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是文件夹:0不是，1是',
  `parent_id` int(9) NOT NULL DEFAULT '0' COMMENT '父级id，默认为0',
  `file_size` int(11) NOT NULL DEFAULT '0' COMMENT '文件大小：单位：kb',
  `down_load_id` varchar(64) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '保存到服务端的下载路径，只有文件才会有路径',
  `create_by` varchar(30) NOT NULL DEFAULT '' COMMENT '创建人',
  `update_by` varchar(30) NOT NULL DEFAULT '' COMMENT '更新人',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1546 DEFAULT CHARSET=utf8 COMMENT='文件信息表';

-- ----------------------------
-- Table structure for fs_manager_info
-- ----------------------------
DROP TABLE IF EXISTS `fs_manager_info`;
CREATE TABLE `fs_manager_info` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `account` varchar(30) NOT NULL COMMENT '账号',
  `password` varchar(64) NOT NULL COMMENT '密码',
  `account_name` varchar(60) NOT NULL DEFAULT '' COMMENT '账号名称',
  `create_by` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '创建人',
  `update_by` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '更新人',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='管理员信息表';

-- ----------------------------
-- Table structure for fs_white_list_info
-- ----------------------------
DROP TABLE IF EXISTS `fs_white_list_info`;
CREATE TABLE `fs_white_list_info` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(30) NOT NULL COMMENT '白名单ip地址',
  `catalog_id` int(9) NOT NULL COMMENT '允许访问的目录id',
  `create_by` varchar(30) NOT NULL DEFAULT '' COMMENT '创建人',
  `update_by` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '更新人',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8 COMMENT='白名单信息表';
