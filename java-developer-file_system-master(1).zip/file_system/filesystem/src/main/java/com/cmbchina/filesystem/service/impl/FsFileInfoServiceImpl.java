package com.cmbchina.filesystem.service.impl;

import com.cmbchina.filesystem.common.constant.CommonConstant;
import com.cmbchina.filesystem.common.enums.FileEnum;
import com.cmbchina.filesystem.config.property.SystemProperty;
import com.cmbchina.filesystem.entity.FsFileInfo;
import com.cmbchina.filesystem.exception.ServiceException;
import com.cmbchina.filesystem.manager.FsFileInfoManager;
import com.cmbchina.filesystem.service.FsFileInfoService;
import com.cmbchina.filesystem.service.FsWhiteListInfoService;
import com.cmbchina.filesystem.utils.FileUtil;
import com.cmbchina.filesystem.utils.VerificationUtils;
import com.cmbchina.filesystem.vo.FileInfoVO;
import com.cmbchina.filesystem.vo.WhiteListInfoVO;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/12/1 16:39
 * @Description:
 */
@Service
public class FsFileInfoServiceImpl implements FsFileInfoService {

    public static Logger logger = LoggerFactory.getLogger(FsFileInfoServiceImpl.class);

    @Resource
    private FsFileInfoManager fsFileInfoManager;

    @Resource
    private FsWhiteListInfoService fsWhiteListInfoService;

    @Resource
    private SystemProperty systemProperty;

    @Override
    public void createDirectory(FileInfoVO fileInfoVO, String createBy) throws Exception {
        VerificationUtils.isStringEmpty(fileInfoVO.getFileName(), "文件夹名称不能为空");
        // 校验文件夹名称是否已存在
        Integer parentId = fileInfoVO.getParentId() == null ? CommonConstant.ROOT_PARENT_ID : fileInfoVO.getParentId();
        FsFileInfo fsFileInfo = fsFileInfoManager.getOneByFileNameAndParentId(fileInfoVO.getFileName(), parentId);
        VerificationUtils.isNotNull(fsFileInfo, "该目录下文件夹名称已存在");
        // 创建文件夹
        fsFileInfoManager.createDirectory(fileInfoVO.getFileName(), parentId, createBy);
    }

    @Override
    public void createFile(FileInfoVO fileInfoVO, String createBy, MultipartFile file) throws Exception {
        String fileName = file.getOriginalFilename();
        // 校验文件名称是否已存在
        Integer parentId = fileInfoVO.getParentId() == null ? CommonConstant.ROOT_PARENT_ID : fileInfoVO.getParentId();

        this.operateFile(fileName, parentId, file, createBy);
    }

    @Override
    public FileInfoVO uploadFile(MultipartFile file, String downLoadId) throws Exception {
        // 获取文件名
        String fileName = file.getOriginalFilename();
        // 获取文件的后缀名
        String suffixName = fileName.substring(fileName.lastIndexOf("."));
        if (downLoadId == null) {
            downLoadId = FileUtil.generateFileId();
        }
        String downLoadFileName = downLoadId + suffixName;
        File dest = new File(systemProperty.getFilePrePath() + downLoadFileName);
        // 检测是否存在目录
        if (!dest.getParentFile().exists()) {
            dest.getParentFile().mkdirs();
        }
        file.transferTo(dest);
        FileInfoVO fileInfoVO = new FileInfoVO();
        if (StringUtils.isBlank(suffixName)) {
            suffixName = "unKnown";
        }
        if (suffixName.startsWith(".")) {
            suffixName = suffixName.substring(1);
        }
        fileInfoVO.setFileType(suffixName);
        fileInfoVO.setDownLoadId(downLoadId);
        fileInfoVO.setFileName(fileName);
        fileInfoVO.setFileSize(FileUtil.getKBFileSize(file.getSize()));
        return fileInfoVO;
    }

    @Override
    public void batchUploadFiles(MultipartFile[] fileList, FileInfoVO fileInfoVO, String createBy) throws Exception {
        if (fileList.length == 0) {
            throw new ServiceException("上传的文件为空");
        }
        Integer parentId = fileInfoVO.getParentId() == null ? CommonConstant.ROOT_PARENT_ID : fileInfoVO.getParentId();
        for (MultipartFile multipartFile : fileList) {
            // 获取文件名
            String fileUrl = multipartFile.getOriginalFilename();

            if (fileUrl.contains("/")) {
                Integer parentIdTemp = parentId;
                String[] fileNameArray = fileUrl.split("[/]");
                for (int i = 0; i < fileNameArray.length - 1; i++) {
                    String directoryName = fileNameArray[i];
                    FsFileInfo directory = fsFileInfoManager.getOneByFileNameAndParentId(directoryName, parentIdTemp);
                    if (directory == null) {
                        directory = fsFileInfoManager.createDirectory(directoryName, parentIdTemp, createBy);
                    }
                    parentIdTemp = directory.getId();
                }
                //保存文件
                String fileName = fileNameArray[fileNameArray.length - 1];

                this.operateFile(fileName, parentIdTemp, multipartFile, createBy);

            } else {
                this.createFile(fileInfoVO, createBy, multipartFile);
            }
        }
    }

    /**
     * 操作文件，如果文件已存在，则覆盖文件，若不存在则新增
     *
     * @param fileName
     * @param parentId
     * @param multipartFile
     * @param createBy
     * @throws Exception
     */
    private void operateFile(String fileName, Integer parentId, MultipartFile multipartFile, String createBy) throws Exception {
        FsFileInfo fsFileInfo = fsFileInfoManager.getOneByFileNameAndParentId(fileName, parentId);
        if (fsFileInfo != null) {
            //覆盖远程文件
            FileInfoVO fileInfoVO = this.uploadFile(multipartFile, fsFileInfo.getDownLoadId());
            // 更新文件信息
            fileInfoVO.setId(fsFileInfo.getId());
            fsFileInfoManager.update(fileInfoVO, createBy);
        } else {
            // 创建新文件
            this.createFile(multipartFile, createBy, fileName, parentId);
        }
    }

    /**
     * 创建新文件
     *
     * @param multipartFile
     * @param createBy
     * @param fileName
     * @param parentId
     * @throws Exception
     */
    private void createFile(MultipartFile multipartFile, String createBy, String fileName, Integer parentId) throws Exception {
        FileInfoVO fileInfoVO = this.uploadFile(multipartFile, null);
        fileInfoVO.setCreateBy(createBy);
        fileInfoVO.setFileName(fileName);// 上传文件夹时，文件名称会包含文件夹，所以这里通过外面传进来
        fileInfoVO.setIsDirectory(FileEnum.FILE.getCode());
        fileInfoVO.setParentId(parentId);
        fsFileInfoManager.createFile(fileInfoVO);
    }

    @Override
    public void downLoadFile(HttpServletResponse response, String downLoadId, String fileType) throws Exception {

        FsFileInfo fsFileInfo = fsFileInfoManager.getOneByDownLoadIdAndFileType(downLoadId, fileType);
        if (fsFileInfo == null) {
            String message = String.format("下载id为%s，文件类型为%s的文件在服务端没有找到", downLoadId, fileType);
            logger.error(message);
            return;
        }
        String realFileName = downLoadId + "." + fileType;
        String fileName = fsFileInfo.getFileName();
        File file = new File(systemProperty.getFilePrePath(), realFileName);
        if (file.exists()) {
            response.setContentType("application/octet-stream;charset=UTF-8");
            response.addHeader("Content-Disposition", "attachment;fileName=" + java.net.URLEncoder.encode(fileName, "UTF-8"));// 设置文件名
            byte[] buffer = new byte[1024];
            FileInputStream fis = null;
            BufferedInputStream bis = null;
            try {
                fis = new FileInputStream(file);
                bis = new BufferedInputStream(fis);
                OutputStream os = response.getOutputStream();
                int i = bis.read(buffer);
                while (i != -1) {
                    os.write(buffer, 0, i);
                    i = bis.read(buffer);
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            } finally {
                if (bis != null) {
                    bis.close();
                }
                if (fis != null) {
                    fis.close();
                }
            }
        }
    }

    @Override
    public void downLoadFile(HttpServletResponse response, String downLoadId, String fileType, String ipAddress, Integer fileId) throws Exception {
        // 校验当前ip是否允许下载该文件
        if (!fsFileInfoManager.checkIpContainsCatalogId(ipAddress, fileId)) {
            throw new ServiceException("您没有下载该文件的权限");
        }
        this.downLoadFile(response, downLoadId, fileType);
    }

    @Override
    public List<FileInfoVO> showCurrentCatalog(Integer parentId, String account, String ipAddress, boolean showWhiteLst) throws Exception {
        List<FileInfoVO> fileInfoVOList = new ArrayList<>();
        List<FsFileInfo> fsFileInfoList = null;
        if (parentId == null) {
            if (StringUtils.isNotBlank(account)) {
                //查询当前账号根目录下的所有文件或文件夹
                fsFileInfoList = fsFileInfoManager.getRootListByAccount(account);
            } else if (StringUtils.isNotBlank(ipAddress)) {
                // 查询当前ip地址下白名单表中允许访问的所有目录或文件
                fsFileInfoList = fsFileInfoManager.getListByIpAddress(ipAddress);
            }
        } else {
            if (StringUtils.isNotBlank(ipAddress)) {
                // 校验当前parentId是否是该白名单下允许访问的，即先查询出当前白名单下所有允许访问的目录和子目录，再进行校验
                fsFileInfoList = fsFileInfoManager.getChildrenListByParentIdAndIp(parentId, ipAddress);
            } else {
                // 查询当前parentId的一级子目录下所有文件或文件夹
                fsFileInfoList = fsFileInfoManager.getChildrenListByParentId(parentId);
            }
        }
        return doList2VoList(fsFileInfoList, showWhiteLst);
    }

    @Override
    public List<FileInfoVO> showCurrentCatalog(Integer parentId, String account) throws Exception {
        VerificationUtils.isStringEmpty(account, "账号不能为空");
        List<FsFileInfo> fsFileInfoList = null;
        if (parentId == null) {
            //查询当前账号根目录下的所有文件或文件夹
            fsFileInfoList = fsFileInfoManager.getRootListByAccount(account);
        } else {
            // 查询当前parentId的一级子目录下所有文件或文件夹
            fsFileInfoList = fsFileInfoManager.getChildrenListByParentId(parentId);
        }
        return doList2VoList(fsFileInfoList, true);
    }

    @Override
    public List<FileInfoVO> showCurrentCatalog(String ipAddress, Integer parentId) throws Exception {
        VerificationUtils.isStringEmpty(ipAddress, "ip地址不能为空");
        List<FsFileInfo> fsFileInfoList = null;
        if (parentId == null) {
            // 查询当前ip地址下白名单表中允许访问的所有目录或文件
            fsFileInfoList = fsFileInfoManager.getListByIpAddress(ipAddress);
        } else {
            // 校验当前parentId是否是该白名单下允许访问的，即先查询出当前白名单下所有允许访问的目录和子目录，再进行校验
            fsFileInfoList = fsFileInfoManager.getChildrenListByParentIdAndIp(parentId, ipAddress);
        }
        return doList2VoList(fsFileInfoList, false);
    }

    @Override
    public void updateFileName(FileInfoVO fileInfoVO, String updateBy) throws Exception {
        VerificationUtils.isStringEmpty(fileInfoVO.getFileName(), "名称不能为空");
        VerificationUtils.isNull(fileInfoVO.getId(), "id不能为空");
        FsFileInfo fsFileInfo = fsFileInfoManager.selectById(fileInfoVO.getId());
        if (fsFileInfo == null) {
            throw new ServiceException("该文件或文件夹不存在");
        }
        FsFileInfo fsFileInfoTemp = fsFileInfoManager.getOneByFileNameAndFileType(fileInfoVO.getFileName(), fileInfoVO.getFileType());
        if (fsFileInfoTemp != null && fsFileInfoTemp.getId().intValue() != fileInfoVO.getId().intValue()) {
            throw new ServiceException("该名称已存在");
        }
        // 如果是文件，判断文件名的后缀是否修改，若修改，则修改文件类型
        if (FileEnum.FILE.getCode() == fsFileInfo.getIsDirectory()) {
            String[] array = fileInfoVO.getFileName().split("[.]");
            String fileType = array[array.length - 1];
            if (!fileType.equals(fsFileInfo.getFileType())) {
                fileInfoVO.setFileType(fileType);
            }
        }
        fsFileInfoManager.update(fileInfoVO, updateBy);
    }

    @Override
    @Transactional
    public void deleteFile(Integer fileId) throws Exception {
        VerificationUtils.isNull(fileId, "id不能为空");
        FsFileInfo fsFileInfo = fsFileInfoManager.selectById(fileId);
        if (fsFileInfo == null) {
            throw new ServiceException("该文件或文件夹不存在");
        }
        this.deleteById(fsFileInfo);
    }

    @Override
    public void batchDeleteFiles(String fileIds) throws Exception {
        VerificationUtils.isStringEmpty(fileIds, "id不能为空");
        String[] fileIdArray = fileIds.split("[,，]");
        for (String fileId : fileIdArray) {
            this.deleteFile(Integer.parseInt(fileId));
        }
    }

    @Override
    public void zipDirectory(Integer parentId, HttpServletResponse response) throws Exception {
        //先查询该文件夹是否存在
        FsFileInfo fsFileInfo = fsFileInfoManager.selectById(parentId);
        VerificationUtils.isNull(fsFileInfo, "该目录不存在");
        String zipName = String.format("%s.zip", fsFileInfo.getFileName());

        String baseName = "";
        if (FileEnum.FILE.getCode() == fsFileInfo.getIsDirectory()) {
            baseName = fsFileInfo.getFileName();
        }
        response.setContentType("application/octet-stream;charset=UTF-8");
        response.addHeader("Content-Disposition", "attachment;fileName=" + java.net.URLEncoder.encode(zipName, "UTF-8"));// 设置文件名
        ZipOutputStream zipOutputStream = new ZipOutputStream(response.getOutputStream());
        // 查询出该目录下的所有目录及文件
        this.zip(baseName, fsFileInfo, zipOutputStream);
        // 先关闭流，不然压缩文件会损坏
        zipOutputStream.close();
    }

    @Override
    public void zipPackage(String parentIds, HttpServletResponse response) throws Exception {
        VerificationUtils.isStringEmpty(parentIds, "目录id不能为空");
        String[] parentIdArray = parentIds.split("[,，]");
        String zipName = String.format("%s.zip", UUID.randomUUID().toString());
        response.setContentType("application/octet-stream;charset=UTF-8");
        response.addHeader("Content-Disposition", "attachment;fileName=" + java.net.URLEncoder.encode(zipName, "UTF-8"));// 设置文件名
        ZipOutputStream zipOutputStream = new ZipOutputStream(response.getOutputStream());
        for (String parentId : parentIdArray) {
            FsFileInfo fsFileInfo = fsFileInfoManager.selectById(parentId);
            VerificationUtils.isNull(fsFileInfo, "该目录不存在");
            String baseName = fsFileInfo.getFileName();
            this.zip(baseName, fsFileInfo, zipOutputStream);
        }
        zipOutputStream.close();
    }

    private void zip(String baseName, FsFileInfo fsFileInfo, ZipOutputStream out) throws Exception {

        if (FileEnum.DIRECTORY.getCode() == fsFileInfo.getIsDirectory()) {
        // 查询parentId下的所有目录
            List<FsFileInfo> childrenList = fsFileInfoManager.getChildrenListByParentId(fsFileInfo.getId());
            baseName = baseName == "" ? "" : baseName + "/";
            for (FsFileInfo fileInfo : childrenList) {
                this.zip(baseName + fileInfo.getFileName(), fileInfo, out);
            }
        } else {
            out.putNextEntry(new ZipEntry(baseName));
            String realFileName = fsFileInfo.getDownLoadId() + "." + fsFileInfo.getFileType();
            File file = new File(systemProperty.getFilePrePath(), realFileName);
            if (file.exists()) {
                BufferedInputStream in = new BufferedInputStream(new FileInputStream(file));
                int c;

                while ((c = in.read()) != -1) {
                    out.write(c);
                }
                in.close();

            }
        }
    }

    /**
     * 递归删除目录文件
     *
     * @param fsFileInfo
     * @throws Exception
     */
    private void deleteById(FsFileInfo fsFileInfo) throws Exception {
        // 删除对应的白名单
        fsWhiteListInfoService.deleteByCatalogId(fsFileInfo.getId());

        if (FileEnum.FILE.getCode() == fsFileInfo.getIsDirectory()) {
            // 如果是文件，直接删除
            //TODO:删除服务器中的文件
            String filePath = FileUtil.getFilePath(fsFileInfo.getDownLoadId(), fsFileInfo.getFileType(), systemProperty.getFilePrePath());
            boolean deleteFile = FileUtil.deleteFile(filePath);
            if (!deleteFile) {
                throw new ServiceException("删除文件失败");
            }
            fsFileInfoManager.deleteById(fsFileInfo.getId());
        } else {
            // 如果是文件夹
            fsFileInfoManager.deleteById(fsFileInfo.getId());
            // 删除下面的子目录
            List<FsFileInfo> fsFileInfoList = fsFileInfoManager.getChildrenListByParentId(fsFileInfo.getId());
            if (CollectionUtils.isNotEmpty(fsFileInfoList)) {
                for (FsFileInfo fsFileInfoTemp : fsFileInfoList) {
                    this.deleteById(fsFileInfoTemp);
                }
            }
        }
    }

    private List<FileInfoVO> doList2VoList(List<FsFileInfo> fsFileInfoList, boolean showWhiteLst) throws Exception {
        List<FileInfoVO> fileInfoVOList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(fsFileInfoList)) {
            FileInfoVO fileInfoVO = null;
            List<WhiteListInfoVO> whiteListInfoVOList = null;
            for (FsFileInfo fsFileInfo : fsFileInfoList) {
                fileInfoVO = new FileInfoVO();
                BeanUtils.copyProperties(fileInfoVO, fsFileInfo);
                if (showWhiteLst) {
                    // 展示当前目录下授权的白名单
                    whiteListInfoVOList = fsWhiteListInfoService.getListByCatalogId(fsFileInfo.getId());
                    fileInfoVO.setWhiteList(whiteListInfoVOList);
                }
                fileInfoVOList.add(fileInfoVO);
            }
        }
        return fileInfoVOList;
    }


}
