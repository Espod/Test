package com.cmbchina.filesystem.utils.token;

import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.cmbchina.filesystem.vo.TokenInfoVO;

import java.util.Date;

/**
 * @Author chenxianqiang
 * @Time 2018/9/11 0011 16:39
 */
public class TokenUtils {

    public static TokenState verifierToken(String token, Algorithm algorithm) {

        DecodedJWT jwt = null;
        try {
            jwt = TokenInfoVO.verifierTokenString(token, algorithm);
        } catch (Exception e) {
            return TokenState.INVALID;
        }

        if (jwt == null) {
            return TokenState.INVALID;
        }

        //非法认证
        Claim notBeforeTime = null;

        try {
            notBeforeTime = jwt.getClaim("notBeforeTime");

            if (notBeforeTime == null) {
                return TokenState.INVALID;
            }
        } catch (Exception e) {
            return TokenState.INVALID;
        }

        if (new Date().before(notBeforeTime.asDate())) {
            // 无效 Token
            return TokenState.INVALID;
        }

        //过期认证
        Claim expTime = null;
        try {
            expTime = jwt.getClaim("expTime");

            if (expTime == null) {
                return TokenState.INVALID;
            }

        } catch (Exception e) {
            return TokenState.INVALID;
        }

        if (new Date().after(expTime.asDate())) {
            // Token 过期
            return TokenState.EXPIRED;
        }

        //用户认证
        Claim userId = null;
        try {
            userId = jwt.getClaim("userId");

            if (userId == null) {
                return TokenState.USER_NULL;
            }

        } catch (Exception e) {
            return TokenState.INVALID;
        }

        //用户认证
        Claim password = null;
        try {
            password = jwt.getClaim("password");

            if (password == null) {
                return TokenState.PASS_NULL;
            }

        } catch (Exception e) {
            return TokenState.INVALID;
        }

        // 认证Token
        return TokenState.VALID;
    }
}
