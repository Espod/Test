package com.cmbchina.filesystem.utils;

import java.io.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/12/1 19:31
 * @Description:
 */
public class FileUtil {

    /**
     * 功能描述: 生成文件id
     *
     * @param: []
     * @return: java.lang.String
     * @auther: chenxianqiang
     * @date: 2018/12/1 19:32
     */
    public static String generateFileId() {
        return UUID.randomUUID().toString();
    }

    /**
     * 删除文件
     *
     * @param filePath
     */
    public static boolean deleteFile(String filePath) {
        File file = new File(filePath);
        if (file.exists() && file.isFile()){
            return file.delete();
        }
        return false;
    }

    /**
     * 获取服务器文件路径
     * @param downloadId
     * @param fileType
     * @param filePath
     * @return
     */
    public static String getFilePath(String downloadId, String fileType, String filePath) {
        StringBuffer filePathBuffer = new StringBuffer();
        filePathBuffer.append(filePath)
                .append("/").append(downloadId).append(".").append(fileType);
        return filePathBuffer.toString();
    }

    /**
     * 获取以kb为单位的文件大小
     * @param fileSize
     * @return
     */
    public static Long getKBFileSize(Long fileSize) {
        if (fileSize == null) {
            return 0L;
        }
        BigDecimal fileSizeBigDecimal = BigDecimal.valueOf(fileSize);
        BigDecimal divide = fileSizeBigDecimal.divide(BigDecimal.valueOf(1024), 0, RoundingMode.HALF_UP);
        // 不到1KB的设置为1KB
        if (divide.compareTo(BigDecimal.ZERO) == 0 && fileSize > 0) {
            divide = BigDecimal.valueOf(1);
        }
        return divide.longValue();
    }



}
