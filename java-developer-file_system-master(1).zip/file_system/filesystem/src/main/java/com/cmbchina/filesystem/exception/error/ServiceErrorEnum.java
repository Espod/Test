package com.cmbchina.filesystem.exception.error;

/**
 * 逻辑业务异常 <br/>
 * 1：通用异常 <br/>
 * 2：远端接口异常 <br/>
 * 3：服务接口异常 <br/>
 * 例如：S001_3 0000 0000;  <br/>
 * S : 表示服务异常 <br/>
 * 001 : 表示Product 商品中心 <br/>
 * 3表示服务接口异常，3的后四位表示具体业务所属的实体类型，末尾的4位数表示具体业务异常 <br/>
 */
public enum ServiceErrorEnum {

    /**
     * 对象为空异常
     */
    NULL("S007_NULL", "S007100000000"),
    /**
     * 转换异常
     */
    CONVERT("S007_CONVERT", "S007100000001"),
    /**
     * 拷贝值异常
     */
    VALUE_COPY("S007_VALUE_COPY", "S007100000002"),
    /**
     * 值不合法异常
     */
    VALUE_NO_LEGALITY("S007_VALUE_NO_LEGALITY", "S007100000003"),
    /**
     * 日期不合法异常
     */
    DATE_NO_LEGALITY("S007_DATE_NO_LEGALITY", "S007100000004"),
    /**
     * 证件不合法异常
     */
    CERTIFICATE_NO_LEGALITY("S007_CERTIFICATE_NO_LEGALITY", "S007100000005"),
    /**
     * 联系方式不合法异常
     */
    PHONE_NO_LEGALITY("S007_PHONE_NO_LEGALITY", "S007100000006"),
    /**
     * 邮件不合法异常
     */
    EMAIL_NO_LEGALITY("S007_EMAIL_NO_LEGALITY", "S007100000007"),
    /**
     * URL不合法异常
     */
    URL_NO_LEGALITY("S007_URL_NO_LEGALITY", "S007100000008"),
    /**
     * 空字符串异常
     */
    STRING_EMPTY("S007_STRING_EMPTY", "S007100000009"),

    /**
     * 存在异常
     */
    EXIST("S007_EXIST", "S007100000010"),

    /**
     * 不存在异常
     */
    NOT_EXIST("S007_NOT_EXIST", "S007100000011"),


    /**
     * 三方远端接口调用异常
     */
    THIRD_PARTY_INTERFACE("S007_THIRD_PARTY_INTERFACE", "S007200000000"),


    /**
     * 白名单信息 插入异常
     */
    WHITE_LIST_INFO_INSERT("S007_WHITE_LIST_INFO_INSERT", "S007301000000"),
    /**
     * 白名单信息 编辑异常
     */
    WHITE_LIST_INFO_UPDATE("S007_WHITE_LIST_INFO_INSERT", "S007301000001"),

    /**
     * 白名单信息 删除异常
     */
    WHITE_LIST_INFO_DELETE("S007_WHITE_LIST_INFO_INSERT", "S007301000001"),
    /**
     * 白名单信息 查询异常
     */
    WHITE_LIST_INFO_QUERY("S007_WHITE_LIST_INFO_INSERT", "S007301000001"),

    ;




    /**
     * 异常名称
     */
    private String name;

    /**
     * 异常代码
     */
    private String code;

    private ServiceErrorEnum(String name, String code) {
        this.name = name;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
