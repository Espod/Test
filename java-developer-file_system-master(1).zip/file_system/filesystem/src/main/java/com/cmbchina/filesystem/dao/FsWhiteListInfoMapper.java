package com.cmbchina.filesystem.dao;

import com.cmbchina.filesystem.entity.FsWhiteListInfo;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  * 白名单信息表 Mapper 接口
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
public interface FsWhiteListInfoMapper extends BaseMapper<FsWhiteListInfo> {

}