package com.cmbchina.filesystem.entity;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 文件信息表
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
@TableName("fs_file_info")
public class FsFileInfo extends Model<FsFileInfo> {

    private static final long serialVersionUID = 1L;

	@TableId(value="id", type= IdType.AUTO)
	private Integer id;
    /**
     * 文件名称
     */
	@TableField("file_name")
	private String fileName;
    /**
     * 文件类型（文件后缀名）
     */
	@TableField("file_type")
	private String fileType;
    /**
     * 是否是文件夹:0不是，1是
     */
	@TableField("is_directory")
	private Integer isDirectory;
    /**
     * 父级id，默认为0
     */
	@TableField("parent_id")
	private Integer parentId;

	/**
	 * 文件大小：单位：kb
	 */
	@TableField("file_size")
	private Long fileSize;
    /**
     * 保存到服务端的下载路径，只有文件才会有路径
     */
	@TableField("down_load_id")
	private String downLoadId;
    /**
     * 创建人
     */
	@TableField("create_by")
	private String createBy;
    /**
     * 更新人
     */
	@TableField("update_by")
	private String updateBy;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
    /**
     * 更新时间
     */
	@TableField("update_time")
	private Date updateTime;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public Integer getIsDirectory() {
		return isDirectory;
	}

	public void setIsDirectory(Integer isDirectory) {
		this.isDirectory = isDirectory;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public String getDownLoadId() {
		return downLoadId;
	}

	public void setDownLoadId(String downLoadId) {
		this.downLoadId = downLoadId;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "FsFileInfo{" +
			", id=" + id +
			", fileName=" + fileName +
			", fileType=" + fileType +
			", isDirectory=" + isDirectory +
			", parentId=" + parentId +
			", fileSize=" + fileSize +
			", downLoadId=" + downLoadId +
			", createBy=" + createBy +
			", updateBy=" + updateBy +
			", createTime=" + createTime +
			", updateTime=" + updateTime +
			"}";
	}
}
