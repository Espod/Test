package com.cmbchina.filesystem.utils;

import java.util.ArrayList;
import java.util.List;

public class ListUtil {

	/**
	 * 
	 * 功能描述: 字符串转换为String类型的list
	 * 
	 * @param param
	 * @param split
	 * @return
	 */
	public static List<String> String2List(String param, String split) {
		if (split == null) {
			split = "[,，]";
		}
		String[] array = param.split(split);
		List<String> list = new ArrayList<>();
		for (String str : array) {
			list.add(str);
		}
		return list;
	}

	public static List<String> String2List(String param) {
		return String2List(param, null);
	}

	/**
	 * 
	 * 功能描述: 字符串转换为Integer类型的list
	 * 
	 * @param param
	 * @param split
	 * @return
	 */
	public static List<Integer> Integers2List(String param, String split) {
		if (split == null) {
			split = "[,，]";
		}
		String[] array = param.split(split);
		List<Integer> list = new ArrayList<>();
		for (String str : array) {
			list.add(Integer.parseInt(str));
		}
		return list;
	}

	public static List<Integer> Integers2List(String param) {
		return Integers2List(param, null);
	}
}
