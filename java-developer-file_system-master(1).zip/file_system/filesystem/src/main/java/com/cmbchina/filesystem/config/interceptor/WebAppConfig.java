package com.cmbchina.filesystem.config.interceptor;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;

/**
 * WEB应用 配置
 *
 * @Author yuyang@qxy37.com
 * @Time 2018/9/11 0011 16:31
 */
@Configuration
public class WebAppConfig implements WebMvcConfigurer {

	@Resource
	private WebAuthedTokenInterceptor webAuthedTokenInterceptor;
	@Resource
	private WebAuthedWhiteListInterceptor webAuthedWhiteListInterceptor;
	
	/**
	 * 添加拦截器
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(webAuthedTokenInterceptor).addPathPatterns("/auth/token/**");
		registry.addInterceptor(webAuthedWhiteListInterceptor).addPathPatterns("/auth/white/**");
	}

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		//跨域配置
		registry.addMapping("/**")
				.allowedOrigins("*")
				.allowedMethods("*")
				.allowCredentials(true);
	}
}
