package com.cmbchina.filesystem.controller;


import com.cmbchina.filesystem.controller.base.TokenController;
import com.cmbchina.filesystem.service.FsManagerInfoService;
import com.cmbchina.filesystem.utils.http.RESP;
import com.cmbchina.filesystem.vo.ManagerInfoVO;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * <p>
 * 管理员信息表 前端控制器
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
@RestController
@RequestMapping("/auth/token/manager")
public class FsManagerInfoController extends TokenController {

    @Resource
    private FsManagerInfoService fsManagerInfoService;

    /**
     *
     * 功能描述: 修改密码
     * @param: [password, oldPassword]
     * @return: com.cmbchina.filesystem.utils.http.RESP<?>
     * @auther: chenxianqiang
     * @date: 2018/12/1 16:35
     */
    @PostMapping("/modify/password")
    public RESP<?> modifyPassword(@RequestBody ManagerInfoVO managerInfoVO) {

        try {

            String userId = getUserId();
            fsManagerInfoService.modifyPassword(managerInfoVO.getOldPassword(), managerInfoVO.getPassword(), userId);

        } catch (Exception e) {

            return assembleExceptionMessage(e);
        }
        return RESP.respSuccess("修改成功！");
    }

    /**
     * 获取管理员信息
     * @return
     */
    @PostMapping("/info")
    public RESP<?> getManagerInfo() {

        ManagerInfoVO managerInfoVO = null;
        try {
            String account = getUserId();
            managerInfoVO = fsManagerInfoService.getByAccount(account);
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
        return RESP.respSuccess("查询成功！", managerInfoVO);
    }
}
