package com.cmbchina.filesystem.manager.impl;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cmbchina.filesystem.dao.FsManagerInfoMapper;
import com.cmbchina.filesystem.entity.FsManagerInfo;
import com.cmbchina.filesystem.manager.FsManagerInfoManager;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 * 管理员信息表 服务实现类
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
@Service
public class FsManagerInfoManagerImpl extends ServiceImpl<FsManagerInfoMapper, FsManagerInfo> implements FsManagerInfoManager {

    @Resource
    private FsManagerInfoMapper fsManagerInfoMapper;


    @Override
    public FsManagerInfo getOneByAccount(String account) {
        FsManagerInfo fsManagerInfo = new FsManagerInfo();
        fsManagerInfo.setAccount(account);
        return fsManagerInfoMapper.selectOne(fsManagerInfo);
    }
}
