package com.cmbchina.filesystem.manager.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cmbchina.filesystem.common.constant.CommonConstant;
import com.cmbchina.filesystem.common.enums.FileEnum;
import com.cmbchina.filesystem.dao.FsFileInfoMapper;
import com.cmbchina.filesystem.entity.FsFileInfo;
import com.cmbchina.filesystem.entity.FsWhiteListInfo;
import com.cmbchina.filesystem.manager.FsFileInfoManager;
import com.cmbchina.filesystem.manager.FsWhiteListInfoManager;
import com.cmbchina.filesystem.vo.FileInfoVO;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

/**
 * <p>
 * 文件信息表 服务实现类
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
@Service
public class FsFileInfoManagerImpl extends ServiceImpl<FsFileInfoMapper, FsFileInfo> implements FsFileInfoManager {

    @Resource
    private FsFileInfoMapper fsFileInfoMapper;

    @Resource
    private FsWhiteListInfoManager fsWhiteListInfoManager;

    @Override
    public FsFileInfo getOneByFileNameAndParentId(String fileName, Integer parentId) throws Exception {
        FsFileInfo fsFileInfo = new FsFileInfo();
        fsFileInfo.setFileName(fileName);
        fsFileInfo.setParentId(parentId);
        return fsFileInfoMapper.selectOne(fsFileInfo);
    }

    @Override
    public FsFileInfo createDirectory(String fileName, Integer parentId, String createBy) throws Exception {
        FsFileInfo fsFileInfo = new FsFileInfo();
        fsFileInfo.setIsDirectory(FileEnum.DIRECTORY.getCode());
        fsFileInfo.setParentId(parentId);
        fsFileInfo.setFileName(fileName);
        fsFileInfo.setCreateBy(createBy);
        fsFileInfo.setUpdateBy(createBy);
        fsFileInfoMapper.insert(fsFileInfo);
        return fsFileInfo;
    }

    @Override
    public void createFile(FileInfoVO fileInfoVO) throws Exception {
        FsFileInfo fsFileInfo = new FsFileInfo();
        BeanUtils.copyProperties(fsFileInfo, fileInfoVO);
        fsFileInfo.setUpdateBy(fileInfoVO.getCreateBy());
        fsFileInfoMapper.insert(fsFileInfo);
    }

    @Override
    public FsFileInfo getOneByDownLoadIdAndFileType(String downLoadId, String fileType) throws Exception {
        FsFileInfo fsFileInfo = new FsFileInfo();
        fsFileInfo.setDownLoadId(downLoadId);
        fsFileInfo.setFileType(fileType);
        return fsFileInfoMapper.selectOne(fsFileInfo);
    }

    @Override
    public List<FsFileInfo> getRootListByAccount(String account) throws Exception {
        EntityWrapper<FsFileInfo> wrapper = new EntityWrapper<>();
        wrapper.eq("parent_id", CommonConstant.ROOT_PARENT_ID);
        wrapper.eq("create_by", account);
        wrapper.orderBy("create_time", false);
        wrapper.orderBy("is_directory", false);
        return fsFileInfoMapper.selectList(wrapper);
    }

    @Override
    public List<FsFileInfo> getListByIpAddress(String ipAddress) throws Exception {
        return fsFileInfoMapper.listByIpAddress(ipAddress);
    }

    @Override
    public List<FsFileInfo> getChildrenListByParentId(Integer parentId) throws Exception {
        EntityWrapper<FsFileInfo> wrapper = new EntityWrapper<>();
        wrapper.eq("parent_id", parentId);
        wrapper.orderBy("create_time", false);
        wrapper.orderBy("is_directory", false);
        return fsFileInfoMapper.selectList(wrapper);
    }

    @Override
    public List<Integer> getAllChildrenDirectoryIdByParentId(Integer parentId, List<Integer> directoryIdList, boolean isDirectory) throws Exception {
        if (CollectionUtils.isEmpty(directoryIdList)) {
            directoryIdList = new ArrayList<>();
        }
        //获取子目录
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("parentId", parentId);
        List<Integer> flaList = new ArrayList<>();
        flaList.add(FileEnum.DIRECTORY.getCode());
        if (!isDirectory) {
            flaList.add(FileEnum.FILE.getCode());
        }
        paramMap.put("list", flaList);
        List<Integer> list = fsFileInfoMapper.listChildrenDirectory(paramMap);
        if (CollectionUtils.isNotEmpty(list)) {
            directoryIdList.addAll(list);
            for (Integer fileId : list) {
                this.getAllChildrenDirectoryIdByParentId(fileId, directoryIdList, isDirectory);
            }
        }
        return directoryIdList;
    }


    @Override
    public List<FsFileInfo> getChildrenListByParentIdAndIp(Integer parentId, String ipAddress) throws Exception {
        List<FsFileInfo> fsFileInfoList = null;
        List<Integer> directoryIdList = this.getAllChildrenIdByIp(ipAddress, true);
        if (CollectionUtils.isNotEmpty(directoryIdList) && directoryIdList.contains(parentId)) {
            // 查询当前目录下的子文件和文件夹
            EntityWrapper<FsFileInfo> wrapper = new EntityWrapper<>();
            wrapper.eq("parent_id", parentId);
            wrapper.orderBy("create_time", false);
            wrapper.orderBy("is_directory", false);
            fsFileInfoList = fsFileInfoMapper.selectList(wrapper);
        }
        return fsFileInfoList;
    }

    @Override
    public List<Integer> getAllChildrenIdByIp(String ipAddress, boolean isDirectory) throws Exception {
        List<Integer> directoryIdList = new ArrayList<>();
        // 通过ip地址先查询出白名单表中保存的允许访问的目录
        List<FsWhiteListInfo> fsWhiteListInfoList = fsWhiteListInfoManager.getListByIpAddress(ipAddress);
        if (CollectionUtils.isNotEmpty(fsWhiteListInfoList)) {
            List<Integer> tempList = null;
            for (FsWhiteListInfo fsWhiteListInfo : fsWhiteListInfoList) {
                directoryIdList.add(fsWhiteListInfo.getCatalogId());
                // 用递归去查询当前目录id下的所有子目录id
                tempList = this.getAllChildrenDirectoryIdByParentId(fsWhiteListInfo.getCatalogId(), null, isDirectory);
                directoryIdList.addAll(tempList);
            }
        }
        return directoryIdList;
    }

    @Override
    public boolean checkIpContainsCatalogId(String ipAddress, Integer catalogId) throws Exception {
        // 先查询白名单列表是否包含当前目录id，若是，则直接返回true
        List<FsWhiteListInfo> fsWhiteListInfoList = fsWhiteListInfoManager.getListByIpAddress(ipAddress);
        if (CollectionUtils.isEmpty(fsWhiteListInfoList)) {
            return false;
        }
        boolean isTrue = false;
        for (FsWhiteListInfo fsWhiteListInfo : fsWhiteListInfoList) {

            // 递归查询当前目录下的所有目录及文件是否包含该目录id,在白名单中并不知道该目录是否是文件夹，这里假定是文件夹，有子目录
            isTrue = this.checkCatalogContainsCatalogId(fsWhiteListInfo.getCatalogId(), catalogId, FileEnum.DIRECTORY.getCode());
            if (isTrue) {
                return true;
            }
        }
        return false;
    }

    private boolean checkCatalogContainsCatalogId(Integer catalogId, Integer childCatalogId, Integer isDirectory) throws Exception {
        if (catalogId.intValue() == childCatalogId.intValue()) {
            return true;
        }
        // 如果当前是文件，则不再查询子目录,文件夹才有子目录
        if (FileEnum.FILE.getCode() == isDirectory) {
            return false;
        }
        // 查询当前目录的下一层目录
        List<FsFileInfo> childrenList = this.getChildrenListByParentId(catalogId);
        if (CollectionUtils.isEmpty(childrenList)) {
            return false;
        } else {
            boolean isTrue = false;
            for (FsFileInfo fsFileInfo : childrenList) {
                isTrue = this.checkCatalogContainsCatalogId(fsFileInfo.getId(), childCatalogId, fsFileInfo.getIsDirectory());
                if (isTrue) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public FsFileInfo getOneByFileNameAndFileType(String fileName, String fileType) throws Exception {
        FsFileInfo fsFileInfo = new FsFileInfo();
        fsFileInfo.setFileName(fileName);
        fsFileInfo.setFileType(fileType);
        return fsFileInfoMapper.selectOne(fsFileInfo);
    }

    @Override
    public void update(FileInfoVO fileInfoVO, String updateBy) throws Exception {
        FsFileInfo fsFileInfo = new FsFileInfo();
        BeanUtils.copyProperties(fsFileInfo, fileInfoVO);
        fsFileInfo.setUpdateTime(null);
        fsFileInfo.setUpdateBy(updateBy);
        fsFileInfoMapper.updateById(fsFileInfo);
    }
}
