package com.cmbchina.filesystem.config.token;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @Author yuyang@qxy37.com
 * @Time 2018/9/11 0011 14:09
 */
@Configuration
@ConfigurationProperties(ignoreUnknownFields = false, prefix = "file-system.token")
public class TokenProperties {

    /**
     * 签发人
     */
    private String issuer;

    /**
     * 秘钥
     */
    private String key;

    /**
     * 算法
     */
    private String algorithm;

    /**
     * 过期时间
     */
    private long expTime;

    /**
     * 失效时间
     */
    private long notBeforeTime;

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getAlgorithm() {
        return algorithm;
    }

    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    public long getExpTime() {
        return expTime;
    }

    public void setExpTime(long expTime) {
        this.expTime = expTime;
    }
}
