package com.cmbchina.filesystem.service.impl;

import com.cmbchina.filesystem.entity.FsFileInfo;
import com.cmbchina.filesystem.entity.FsWhiteListInfo;
import com.cmbchina.filesystem.exception.ServiceException;
import com.cmbchina.filesystem.exception.error.ServiceErrorEnum;
import com.cmbchina.filesystem.manager.FsFileInfoManager;
import com.cmbchina.filesystem.manager.FsWhiteListInfoManager;
import com.cmbchina.filesystem.service.FsWhiteListInfoService;
import com.cmbchina.filesystem.utils.VerificationUtils;
import com.cmbchina.filesystem.vo.WhiteListInfoVO;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/12/1 16:21
 * @Description:
 */
@Service
public class FsWhiteListInfoServiceImpl implements FsWhiteListInfoService {

    @Resource
    private FsWhiteListInfoManager fsWhiteListInfoManager;

    @Resource
    private FsFileInfoManager fsFileInfoManager;

    @Override
    public List<WhiteListInfoVO> getListByIpAddress(String ipAddress) throws Exception {
        List<WhiteListInfoVO> whiteListInfoVOList = new ArrayList<>();
        try {
            WhiteListInfoVO whiteListInfoVO = null;
            List<FsWhiteListInfo> fsWhiteListInfoList = fsWhiteListInfoManager.getListByIpAddress(ipAddress);
            if (CollectionUtils.isNotEmpty(fsWhiteListInfoList)) {

                for (FsWhiteListInfo fsWhiteListInfo : fsWhiteListInfoList) {
                    whiteListInfoVO = new WhiteListInfoVO();
                    BeanUtils.copyProperties(whiteListInfoVO, fsWhiteListInfo);
                    whiteListInfoVOList.add(whiteListInfoVO);
                }
            }
        } catch (Exception e) {
            throw new ServiceException(ServiceErrorEnum.WHITE_LIST_INFO_QUERY, e);
        }
        return whiteListInfoVOList;
    }

    @Override
    @Transactional
    public void batchCreateWhiteList(WhiteListInfoVO whiteListInfoVO, String createBy) throws Exception {
        VerificationUtils.isStringEmpty(whiteListInfoVO.getIpAddress(), "ip地址不能为空");
        VerificationUtils.isNull(whiteListInfoVO.getCatalogId(), "目录id不能为空");
        // 查询目录id是否存在
        FsFileInfo fsFileInfo = fsFileInfoManager.selectById(whiteListInfoVO.getCatalogId());
        VerificationUtils.isNull(fsFileInfo, "当前目录不存在");
        String[] ipAddressArray = whiteListInfoVO.getIpAddress().split("[,，]");
        for (String ipAddress : ipAddressArray) {
            this.createWhiteList(ipAddress, whiteListInfoVO.getCatalogId(), createBy);
        }
    }

    @Override
    public void createWhiteList(String ipAddress, Integer catalogId, String createBy) throws Exception {
        ipAddress = ipAddress.replaceAll("[\\s*|\\t|\\r|\\n]", "");
        // 校验即将新增白名单的目录id是否已在该白名单下包含，若已包含，则无法新增
        if (fsFileInfoManager.checkIpContainsCatalogId(ipAddress, catalogId)) {
            String errorMessage = String.format("重复授权白名单访问该目录,该白名单为：{%s},请核实!", ipAddress);
            throw new ServiceException(errorMessage);
        }
        // 新增白名单
        fsWhiteListInfoManager.insertWhiteList(ipAddress, catalogId, createBy);
    }

    @Override
    public void batchDeleteWhiteList(String ipAddress, Integer catalogId) throws Exception {
        String[] ipAddressArray = ipAddress.split("[,，]");
        for (String ipTemp : ipAddressArray) {
            this.deleteWhiteList(ipTemp, catalogId);
        }
    }

    @Override
    public void deleteWhiteList(String ipAddress, Integer catalogId) throws Exception {
        VerificationUtils.isStringEmpty(ipAddress, "ip地址不能为空");
        VerificationUtils.isNull(catalogId, "目录id不能为空");
        FsWhiteListInfo fsWhiteListInfo = fsWhiteListInfoManager.getOneByIpAddressAndCatalogId(ipAddress, catalogId);
        VerificationUtils.isNull(fsWhiteListInfo, "当前白名单没有直接授权当前目录");
        fsWhiteListInfoManager.deleteById(fsWhiteListInfo.getId());
    }

    @Override
    public List<WhiteListInfoVO> getListByCatalogId(Integer catalogId) throws Exception {
        VerificationUtils.isNull(catalogId, "目录id不能为空");
        List<WhiteListInfoVO> whiteListInfoVOList = new ArrayList<>();
        List<FsWhiteListInfo> fsWhiteListInfoList = fsWhiteListInfoManager.getListByCatalogId(catalogId);
        if (CollectionUtils.isNotEmpty(fsWhiteListInfoList)) {
            WhiteListInfoVO whiteListInfoVO = null;
            for (FsWhiteListInfo fsWhiteListInfo : fsWhiteListInfoList) {
                whiteListInfoVO = new WhiteListInfoVO();
                BeanUtils.copyProperties(whiteListInfoVO, fsWhiteListInfo);
                whiteListInfoVOList.add(whiteListInfoVO);
            }
        }
        return whiteListInfoVOList;
    }

    @Override
    public void deleteByCatalogId(Integer catalogId) throws Exception {
        VerificationUtils.isNull(catalogId, "目录id不能为空");
        fsWhiteListInfoManager.deleteByCatalogId(catalogId);
    }

    @Override
    @Transactional
    public void batchUpdate(WhiteListInfoVO whiteListInfoVO, String updateBy) throws Exception {
        VerificationUtils.isStringEmpty(whiteListInfoVO.getIpAddress(), "ip地址不能为空");
        VerificationUtils.isNull(whiteListInfoVO.getCatalogId(), "目录id不能为空");
        // 先删除
        this.deleteByCatalogId(whiteListInfoVO.getCatalogId());
        // 再新增
        this.batchCreateWhiteList(whiteListInfoVO, updateBy);
    }
}
