package com.cmbchina.filesystem.manager;

import com.baomidou.mybatisplus.service.IService;
import com.cmbchina.filesystem.entity.FsWhiteListInfo;

import java.util.List;

/**
 * <p>
 * 白名单信息表 服务类
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
public interface FsWhiteListInfoManager extends IService<FsWhiteListInfo> {

    /**
     *
     * 功能描述: 通过ip地址查询白名单信息
     * @param: [ipAddress]
     * @return: com.cmbchina.filesystem.entity.FsWhiteListInfo
     * @auther: chenxianqiang
     * @date: 2018/12/1 16:28
     */
    List<FsWhiteListInfo> getListByIpAddress(String ipAddress) throws Exception;

    /**
     *
     * 功能描述: 通过ip和目录id查询指定白名单信息
     * @param: [ipAddress, catalogId]
     * @return: com.cmbchina.filesystem.entity.FsWhiteListInfo
     * @auther: chenxianqiang
     * @date: 2018/12/2 19:06
     */
    FsWhiteListInfo getOneByIpAddressAndCatalogId(String ipAddress, Integer catalogId) throws Exception;

    /**
     *
     * 功能描述: 新增白名单
     * @param: [ipAddress, catalogId, createBy]
     * @return: void
     * @auther: chenxianqiang
     * @date: 2018/12/2 19:29
     */
    void insertWhiteList(String ipAddress, Integer catalogId, String createBy) throws Exception;

    /**
     *
     * 功能描述: 查询该目录下的白名单列表
     * @param: [catalogId]
     * @return: java.util.List<com.cmbchina.filesystem.entity.FsWhiteListInfo>
     * @auther: chenxianqiang
     * @date: 2018/12/2 19:57
     */
    List<FsWhiteListInfo> getListByCatalogId(Integer catalogId) throws Exception;

    /**
     * 删除文件（夹）所关联的白名单
     * @param catalogId
     * @throws Exception
     */
    void deleteByCatalogId(Integer catalogId) throws Exception;
}
