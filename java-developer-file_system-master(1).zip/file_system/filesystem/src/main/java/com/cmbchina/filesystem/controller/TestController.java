package com.cmbchina.filesystem.controller;

import com.cmbchina.filesystem.common.constant.CommonConstant;
import com.cmbchina.filesystem.controller.base.TokenController;
import com.cmbchina.filesystem.utils.http.RESP;
import com.cmbchina.filesystem.vo.FileInfoVO;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/11/30 16:49
 * @Description:
 */
@RestController
@RequestMapping("/auth")
public class TestController extends TokenController {

    @RequestMapping("/index")
    public String index() {
        return "test";
    }



    @GetMapping("/downloadTest")
    public void downloadTest(HttpServletResponse response) throws IOException {
        String fileName="testChm.chm";
        File file = new File(CommonConstant.FILE_PRE_PATH, fileName);
        if (file.exists()) {
            response.setContentType("application/octet-stream;charset=UTF-8");
            response.addHeader("Content-Disposition", "attachment;fileName=" + java.net.URLEncoder.encode(fileName, "UTF-8"));// 设置文件名
            byte[] buffer = new byte[1024];
            FileInputStream fis = null;
            BufferedInputStream bis = null;
            try {
                fis = new FileInputStream(file);
                bis = new BufferedInputStream(fis);
                OutputStream os = response.getOutputStream();
                int i = bis.read(buffer);
                while (i != -1) {
                    os.write(buffer, 0, i);
                    i = bis.read(buffer);
                }
            } catch (Exception e) {
                logger.error(e.getMessage(), e);
            } finally {
                if (bis != null) {
                    bis.close();
                }
                if (fis != null) {
                    fis.close();
                }
            }
        }
    }

    @PostMapping("/test")
    public RESP<?> test() {
        try {
            return RESP.respSuccess("获取信息成功", "test");
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }

    @PostMapping("/batchUpload")
    public RESP<?> batchUpload(@RequestParam("file") MultipartFile[] file, FileInfoVO fileInfoVO) {
        try {
            logger.info("长度"+file.length);
            return RESP.respSuccess("上传成功");
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }
}
