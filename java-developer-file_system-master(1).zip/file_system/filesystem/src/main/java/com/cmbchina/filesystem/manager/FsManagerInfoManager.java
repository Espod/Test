package com.cmbchina.filesystem.manager;

import com.baomidou.mybatisplus.service.IService;
import com.cmbchina.filesystem.entity.FsManagerInfo;

/**
 * <p>
 * 管理员信息表 服务类
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
public interface FsManagerInfoManager extends IService<FsManagerInfo> {

    /**
     *
     * 功能描述: 通过账号查询
     * @param: [account]
     * @return: com.cmbchina.filesystem.entity.FsManagerInfo
     * @auther: chenxianqiang
     * @date: 2018/12/1 16:17
     */
    FsManagerInfo getOneByAccount(String account) throws Exception;
}
