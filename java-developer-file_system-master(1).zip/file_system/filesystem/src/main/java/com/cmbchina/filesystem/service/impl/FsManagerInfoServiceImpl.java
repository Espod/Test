package com.cmbchina.filesystem.service.impl;

import com.cmbchina.filesystem.entity.FsManagerInfo;
import com.cmbchina.filesystem.exception.ServiceException;
import com.cmbchina.filesystem.manager.FsManagerInfoManager;
import com.cmbchina.filesystem.service.FsManagerInfoService;
import com.cmbchina.filesystem.utils.MD5Util;
import com.cmbchina.filesystem.utils.VerificationUtils;
import com.cmbchina.filesystem.vo.ManagerInfoVO;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/12/1 16:15
 * @Description:
 */
@Service
public class FsManagerInfoServiceImpl implements FsManagerInfoService {

    @Resource
    private FsManagerInfoManager fsManagerInfoManager;

    @Override
    public ManagerInfoVO login(ManagerInfoVO managerInfoVO) throws Exception {
        VerificationUtils.isStringEmpty(managerInfoVO.getAccount(), "账号不能为空");
        VerificationUtils.isStringEmpty(managerInfoVO.getPassword(), "密码不能为空");
        String password = MD5Util.doubleMD5(managerInfoVO.getPassword());
        FsManagerInfo fsManagerInfo = fsManagerInfoManager.getOneByAccount(managerInfoVO.getAccount());
        VerificationUtils.isNull(fsManagerInfo, "账号不存在");
        if (!password.equals(fsManagerInfo.getPassword())) {
            throw new ServiceException("密码错误");
        }
        ManagerInfoVO manager = new ManagerInfoVO();
        manager.setAccountName(fsManagerInfo.getAccountName());
        manager.setAccount(fsManagerInfo.getAccount());
        manager.setId(fsManagerInfo.getId());
        return manager;
    }

    @Override
    public void modifyPassword(String oldPassword, String password, String account) throws Exception {
        VerificationUtils.isStringEmpty(account, "账号不能为空");
        VerificationUtils.isStringEmpty(password, "密码不能为空");
        VerificationUtils.isStringEmpty(oldPassword, "原密码不能为空");
        FsManagerInfo fsManagerInfo = fsManagerInfoManager.getOneByAccount(account);
        VerificationUtils.isNull(fsManagerInfo, "账号不存在");
        String oldPasswordTemp = MD5Util.doubleMD5(oldPassword);
        if (!oldPasswordTemp.equals(fsManagerInfo.getPassword())) {
            throw new ServiceException("原密码错误");
        }
        password = MD5Util.doubleMD5(password);
        fsManagerInfo.setPassword(password);
        fsManagerInfoManager.updateById(fsManagerInfo);
    }

    @Override
    public ManagerInfoVO getByAccount(String account) throws Exception {
        ManagerInfoVO managerInfoVO = null;
        FsManagerInfo fsManagerInfo = fsManagerInfoManager.getOneByAccount(account);
        if (fsManagerInfo != null) {
            managerInfoVO = new ManagerInfoVO();
            BeanUtils.copyProperties(managerInfoVO, fsManagerInfo);
            managerInfoVO.setPassword(null);
        }
        return managerInfoVO;
    }
}
