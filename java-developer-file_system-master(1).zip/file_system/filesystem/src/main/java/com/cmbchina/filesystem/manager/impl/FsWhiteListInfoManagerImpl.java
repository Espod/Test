package com.cmbchina.filesystem.manager.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.cmbchina.filesystem.dao.FsWhiteListInfoMapper;
import com.cmbchina.filesystem.entity.FsWhiteListInfo;
import com.cmbchina.filesystem.manager.FsWhiteListInfoManager;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 白名单信息表 服务实现类
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
@Service
public class FsWhiteListInfoManagerImpl extends ServiceImpl<FsWhiteListInfoMapper, FsWhiteListInfo> implements FsWhiteListInfoManager {

    @Resource
    private FsWhiteListInfoMapper fsWhiteListInfoMapper;


    @Override
    public List<FsWhiteListInfo> getListByIpAddress(String ipAddress) throws Exception {
        EntityWrapper<FsWhiteListInfo> wrapper = new EntityWrapper<>();
        wrapper.eq("ip_address", ipAddress);
        return fsWhiteListInfoMapper.selectList(wrapper);
    }

    @Override
    public FsWhiteListInfo getOneByIpAddressAndCatalogId(String ipAddress, Integer catalogId) throws Exception {
        FsWhiteListInfo fsWhiteListInfo = new FsWhiteListInfo();
        fsWhiteListInfo.setIpAddress(ipAddress);
        fsWhiteListInfo.setCatalogId(catalogId);
        return fsWhiteListInfoMapper.selectOne(fsWhiteListInfo);
    }

    @Override
    public void insertWhiteList(String ipAddress, Integer catalogId, String createBy) throws Exception {
        FsWhiteListInfo fsWhiteListInfo = new FsWhiteListInfo();
        fsWhiteListInfo.setCatalogId(catalogId);
        fsWhiteListInfo.setIpAddress(ipAddress);
        fsWhiteListInfo.setCreateBy(createBy);
        fsWhiteListInfo.setUpdateBy(createBy);
        fsWhiteListInfoMapper.insert(fsWhiteListInfo);
    }

    @Override
    public List<FsWhiteListInfo> getListByCatalogId(Integer catalogId) throws Exception {
        EntityWrapper<FsWhiteListInfo> wrapper = new EntityWrapper<>();
        wrapper.eq("catalog_id", catalogId);
        return fsWhiteListInfoMapper.selectList(wrapper);
    }

    @Override
    public void deleteByCatalogId(Integer catalogId) throws Exception {
        EntityWrapper<FsWhiteListInfo> wrapper = new EntityWrapper<>();
        wrapper.eq("catalog_id", catalogId);
        fsWhiteListInfoMapper.delete(wrapper);
    }
}
