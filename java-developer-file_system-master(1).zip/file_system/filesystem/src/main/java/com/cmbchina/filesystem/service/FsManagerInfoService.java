package com.cmbchina.filesystem.service;

import com.cmbchina.filesystem.vo.ManagerInfoVO;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/12/1 16:14
 * @Description:
 */
public interface FsManagerInfoService {

    /**
     *
     * 功能描述: 管理员登录
     * @param: [managerInfoVO]
     * @return: ManagerInfoVO
     * @auther: chenxianqiang
     * @date: 2018/12/1 15:19
     */
    ManagerInfoVO login(ManagerInfoVO managerInfoVO) throws Exception;

    /**
     *
     * 功能描述: 修改密码
     * @param: [oldPassword, password, account]
     * @return: void
     * @auther: chenxianqiang
     * @date: 2018/12/1 16:09
     */
    void modifyPassword(String oldPassword, String password, String account) throws Exception;

    /**
     * 通过账号获取信息
     * @param account
     * @return
     * @throws Exception
     */
    ManagerInfoVO getByAccount(String account) throws Exception;
}
