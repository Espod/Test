package com.cmbchina.filesystem.controller.base;

import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.cmbchina.filesystem.config.token.TokenProperties;
import com.cmbchina.filesystem.utils.token.TokenState;
import com.cmbchina.filesystem.utils.token.TokenUtils;
import com.cmbchina.filesystem.vo.TokenInfoVO;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author chenxianqiang
 * @Time 2018/9/11 0011 13:30
 */
public class TokenController extends BaseController {

    @Autowired
    TokenProperties tokenConfiguration;


    public String createToken(String userId) {
        TokenInfoVO tokenInfoVO = new TokenInfoVO();

        //解析属性
        tokenInfoVO.setUserId(userId);

        //过期时间
        Date expiresAt = new Date();
        expiresAt.setTime(expiresAt.getTime() + tokenConfiguration.getExpTime());
        tokenInfoVO.setExpiresAt(expiresAt);

        tokenInfoVO.setNotBefore(new Date());
        tokenInfoVO.setIssuedAt(new Date());
        tokenInfoVO.setIssuer(tokenConfiguration.getIssuer());

        Map<String, Object> headers = new HashMap<>();
        headers.put("alg", "HMAC512");
        headers.put("typ", "JWT");

        Algorithm algorithm = getAlgorithm();

        String token = TokenInfoVO.createSignToken(tokenInfoVO, algorithm, headers);

//        redisTemplate.opsForValue().set(userId,token);

        return token;
    }

    /**
     * 过期刷新Token
     * @param token token
     * @return
     */
    public String refreshToken(String token) {
        TokenState tokenState = TokenUtils.verifierToken(token,getAlgorithm());
        if(TokenState.EXPIRED.equals(tokenState)){
            return createToken(getTokenUserId(token));
        }else{
            return  token;
        }
    }

    public String getUserId(){
        HttpServletRequest request = getRequest();
        String token = request.getHeader("X-Token");
        return getTokenUserId(token);
    }

    /**
     * 获得TokenUser ID
     * @param token token字符串
     * @return
     */
    public String getTokenUserId(String token){
        Algorithm algorithm = getAlgorithm();

        DecodedJWT jwt = null;
        //用户认证
        Claim userId = null;
        try {
            jwt = TokenInfoVO.verifierTokenString(token, algorithm);

            userId = jwt.getClaim("userId");

            if(userId == null){
                return null;
            }

        } catch (Exception e) {
            return null;
        }

        return userId.asString();
    }

    /**
     * 获得TokenUser 密码
     * @param token token字符串
     * @return
     */
    public String getTokenPassword(String token){
        Algorithm algorithm = getAlgorithm();

        DecodedJWT jwt = null;
        //用户认证
        Claim password = null;
        try {
            jwt = TokenInfoVO.verifierTokenString(token, algorithm);

            password = jwt.getClaim("password");

            if(password == null){
                return null;
            }

        } catch (Exception e) {
            return null;
        }

        return password.asString();
    }

    public TokenProperties getTokenConfiguration() {
        return tokenConfiguration;
    }

    public void setTokenConfiguration(TokenProperties tokenConfiguration) {
        this.tokenConfiguration = tokenConfiguration;
    }

    public Algorithm getAlgorithm() {
        Algorithm algorithm = null;
        if ("DEFAULT".equalsIgnoreCase(tokenConfiguration.getAlgorithm())) {
            algorithm = Algorithm.HMAC512(tokenConfiguration.getKey());
        }
        return algorithm;
    }

    public Algorithm getAlgorithm(String password) {
        Algorithm algorithm = null;
        if ("DEFAULT".equalsIgnoreCase(tokenConfiguration.getAlgorithm())) {
            algorithm = Algorithm.HMAC512(password);
        }
        return algorithm;
    }
}
