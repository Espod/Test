package com.cmbchina.filesystem.utils.http;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.List;

/**
 * 返回结果
 *
 * @Author yuyang@qxy37.com
 * @Time 2018/8/17 0017 13:17
 */
public class RESP<T> {
 
   /**
    * 错误代码
    */
   private String code;
   /**
    * 消息
    */
   private String message;
 
   /**
    * 数据
    */
   private T data;
 
   /**
    * 列表数据
    */
   private List<T> rows;
 
   /**
    * 总的记录数
    */
   private String total;
 
   /**
    * 总的页数
    */
   private String totalPage;
   
   /** 日志记录 */
   public static Logger logger = LoggerFactory.getLogger(RESP.class);
   /** 成功 */
   public static final String SUCCESS = "SUCCESS";
   /** 失败 */
   public static final String FAILED = "FAILED";
   /** 超时 */
   public static final String TIMEOUT = "TIMEOUT";
   /** 未认证 */
   public static final String NOAUTH = "NOAUTH";
   /** token为空 */
   public static final String TOKEN_NULL = "TOKEN_NULL";
   /** 没有数据 */
   public static final String EMPTY = "EMPTY";
   /** 接口已经失效 */
   public static final String DEPRECATED = "DEPRECATED";
   /** 错误接口*/
   public static final String ERRORCOMMAND = "ERRORCOMMAND";
 
   public RESP() {
       super();
   }
 
   public RESP(String code, String message, List<T> rows, String total, String totalPage) {
       super();
       this.code = code;
       this.message = message;
       this.rows = rows;
       this.total = total;
       this.totalPage = totalPage;
   }
 
   public RESP(String code, String message, T data, List<T> rows) {
       super();
       this.code = code;
       this.message = message;
       this.data = data;
       this.rows = rows;
   }
 
   public RESP(String code, String message, T data) {
       super();
       this.code = code;
       this.message = message;
       this.data = data;
   }
 
   public RESP(String code) {
       super();
       this.code = code;
   }
 
   public RESP(String code, String message) {
       super();
       this.code = code;
       this.message = message;
   }
 
   public String getCode() {
       return code;
   }
 
   public void setCode(String code) {
       this.code = code;
   }
 
   public String getMessage() {
       return message;
   }
 
   public void setMessage(String message) {
       this.message = message;
   }
 
   public T getData() {
       return data;
   }
 
   public void setData(T data) {
       this.data = data;
   }
 
   public List<T> getRows() {
       return rows;
   }
 
   public void setRows(List<T> rows) {
       this.rows = rows;
   }
 
   public String getTotal() {
       return total;
   }
 
   public void setTotal(String total) {
       this.total = total;
   }
 
   public String getTotalPage() {
       return totalPage;
   }
 
   public void setTotalPage(String totalPage) {
       this.totalPage = totalPage;
   }

   public static<T>  RESP<T> resp(String code, String message, List<T> rows, String total, String totalPage){
        return  new RESP<>(code,message,rows,total,totalPage);
   }

    public static<T>   RESP<T> resp(String code, String message, T data, List<T> rows){
       return new RESP<>(code,message,data,rows);
    }

    public static<T>  RESP<T> resp(String code, String message, T data){
        return new RESP<>(code,message,data);
    }

    public static<T>  RESP<T> resp(String code, String message){
        return new RESP<>(code,message);
    }

    public static<T>  RESP<T> resp(String code){
        return new RESP<>(code);
    }

    public static<T> RESP<T> respSuccess(String message, List<T> rows, String total, String totalPage){
       return resp(RESP.SUCCESS,message,rows,total,totalPage);
    }
    public static<T> RESP<T> respSuccess(String message, T data, List<T> rows){
        return resp(RESP.SUCCESS,message,data,rows);
    }
    public static<T> RESP<T> respSuccess(String message, T data){
        return resp(RESP.SUCCESS,message,data);
    }

    public static<T> RESP<T> respSuccess(String message){
        return resp(RESP.SUCCESS,message);
    }

    public static<T> RESP<T> respFailed(String message, List<T> rows, String total, String totalPage){
        return resp(RESP.FAILED,message,rows,total,totalPage);
    }
    public static<T> RESP<T> respFailed(String message, T data, List<T> rows){
        return resp(RESP.FAILED,message,data,rows);
    }

    public static<T> RESP<T> respFailed(String message, T data){
        return resp(RESP.FAILED,message,data);
    }

    public static<T> RESP<T> respFailed(String message){
        return resp(RESP.FAILED,message);
    }

   /**
    * 立即返回响应数据 
    * @param response 响应对象
    * @param result 结果 
    */
   public static <T> void responseData(HttpServletResponse response, RESP<T> result) {
       PrintWriter out = null;
       try {
           // 未登录，立即返回
           response.setCharacterEncoding("UTF-8");
           response.setContentType("application/json;charset=UTF-8");
           response.setHeader("Access-Control-Allow-Origin", "*");
           response.setHeader("Access-Control-Allow-Headers", "*");
           ObjectMapper objectMapper = new ObjectMapper();
           String json = objectMapper.writeValueAsString(result);
           out = response.getWriter();
           out.append(json);
       } catch (Exception e) {
           logger.error(e.getMessage());
       } finally {
           if (out != null) {
               out.close();
           }
       }
 
   }
   
}