package com.cmbchina.filesystem.vo;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

/**
 * Token信息
 *
 * @Author yuyang@qxy37.com
 * @Time 2018/9/11 0011 13:31
 */
public class TokenInfoVO implements Serializable {

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 用户密码
     */
    private String password;

    /**
     * 认证状态
     */
    private String statusAuth;

    /**
     * IMEI
     */
    private String internationalMobileEquipmentIdentity;

    /**
     * 操作系统
     */
    private String operatingSystem;

    /**
     * 机器型号
     */
    private String machineModel;

    /**
     * 操作系统版本号
     */
    private String operatingSystemVersion;

    /**
     * 主题
     */
    private String subject;

    /**
     * 签发人
     */
    private String issuer;

    /**
     * 签发时间
     */
    private Date issuedAt;

    /**
     * 失效时间
     */
    private Date notBefore;

    /**
     * 过期时间
     */
    private Date expiresAt;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStatusAuth() {
        return statusAuth;
    }

    public void setStatusAuth(String statusAuth) {
        this.statusAuth = statusAuth;
    }

    public String getInternationalMobileEquipmentIdentity() {
        return internationalMobileEquipmentIdentity;
    }

    public void setInternationalMobileEquipmentIdentity(String internationalMobileEquipmentIdentity) {
        this.internationalMobileEquipmentIdentity = internationalMobileEquipmentIdentity;
    }

    public String getOperatingSystem() {
        return operatingSystem;
    }

    public void setOperatingSystem(String operatingSystem) {
        this.operatingSystem = operatingSystem;
    }

    public String getMachineModel() {
        return machineModel;
    }

    public void setMachineModel(String machineModel) {
        this.machineModel = machineModel;
    }

    public String getOperatingSystemVersion() {
        return operatingSystemVersion;
    }

    public void setOperatingSystemVersion(String operatingSystemVersion) {
        this.operatingSystemVersion = operatingSystemVersion;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public Date getIssuedAt() {
        return issuedAt;
    }

    public void setIssuedAt(Date issuedAt) {
        this.issuedAt = issuedAt;
    }

    public Date getNotBefore() {
        return notBefore;
    }

    public void setNotBefore(Date notBefore) {
        this.notBefore = notBefore;
    }

    public Date getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(Date expiresAt) {
        this.expiresAt = expiresAt;
    }

    public static String createSignToken(TokenInfoVO tokenInfoVO, Algorithm algorithm, Map<String, Object> headers) {
        String token = JWT.create().
                withHeader(headers).
                //自定义属性
                        withClaim("userId", tokenInfoVO.getUserId()).
                        withClaim("password", tokenInfoVO.getPassword()).
                        withClaim("statusAuth", tokenInfoVO.getUserId()).
                        withClaim("internationalMobileEquipmentIdentity", tokenInfoVO.getUserId()).
                        withClaim("operatingSystem", tokenInfoVO.getUserId()).
                        withClaim("machineModel", tokenInfoVO.getUserId()).
                        withClaim("operatingSystemVersion", tokenInfoVO.getUserId()).
                        withClaim("expTime", tokenInfoVO.getExpiresAt()).
                        withClaim("notBeforeTime", tokenInfoVO.getNotBefore()).

                        //签发属性
                        withAudience(tokenInfoVO.getUserId()).
                        withIssuer(tokenInfoVO.getIssuer()).
                        withIssuedAt(tokenInfoVO.getIssuedAt()).
                        withSubject(tokenInfoVO.getSubject()).
                        sign(algorithm);

        return token;
    }

    public static DecodedJWT verifierTokenString(String token, Algorithm algorithm) {
        JWTVerifier verifier = JWT.require(algorithm)
                .build();
        DecodedJWT jwt = verifier.verify(token);
        return jwt;
    }
}
