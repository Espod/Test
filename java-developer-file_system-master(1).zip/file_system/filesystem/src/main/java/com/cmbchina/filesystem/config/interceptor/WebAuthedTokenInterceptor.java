package com.cmbchina.filesystem.config.interceptor;

import com.cmbchina.filesystem.controller.base.TokenController;
import com.cmbchina.filesystem.utils.http.RESP;
import com.cmbchina.filesystem.utils.token.TokenState;
import com.cmbchina.filesystem.utils.token.TokenUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * WEB Token认证拦截器
 *
 * @auther: chenxianqiang
 * @date: 2018/12/1 13:31
 */
@Component
public class WebAuthedTokenInterceptor extends TokenController implements HandlerInterceptor {


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String token = request.getHeader("X-Token");
        if (StringUtils.isBlank(token)) {
            token = request.getParameter("X-Token");
            if (StringUtils.isBlank(token)) {
                RESP.responseData(response, RESP.resp(RESP.TOKEN_NULL, "token 不能为空！"));
                return false;
            }
        }
        TokenState tokenState = TokenUtils.verifierToken(token, getAlgorithm());
        switch (tokenState) {
            case VALID:
                refreshToken(token);
                return true;
            case INVALID:
                RESP.responseData(response, RESP.resp(RESP.FAILED, "无效的token！"));
                return false;
            case PASS_NULL:
                RESP.responseData(response, RESP.resp(RESP.FAILED, "无效的token！"));
                return false;
            case USER_NULL:
                RESP.responseData(response, RESP.resp(RESP.FAILED, "无效的token！"));
                return false;
            case EXPIRED:
                RESP.responseData(response, RESP.resp(RESP.FAILED, "token 已过期！"));
                return false;

        }
        return false;
    }


    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {

    }
}
