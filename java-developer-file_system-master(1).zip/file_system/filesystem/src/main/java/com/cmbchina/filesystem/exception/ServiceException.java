package com.cmbchina.filesystem.exception;


import com.cmbchina.filesystem.exception.error.ServiceErrorEnum;

/**
 * 具体业务错误异常
 *
 * @Author chenxianqiang
 * @Time 2018/8/17 0017 08:57
 */
public class ServiceException extends Exception {

    /**
     * 错误消息
     */
    private String msg;

    /**
     * 错误代码
     */
    private String code;

    /**
     * 错误代码值
     */
    private String value;

    public ServiceException() {
    }

    public ServiceException(String message) {
        super(message);
        this.msg = message;
    }

    public ServiceException(String message, Throwable cause) {
        super(message, cause);
        this.msg = message;
    }

    public ServiceException(Throwable cause) {
        super(cause);
    }

    public ServiceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.msg = message;
    }

    public ServiceException(ServiceErrorEnum code, Throwable cause) {
        super(cause);
        this.code = code.getCode();
        this.value = code.getName();
    }

    public ServiceException(ServiceErrorEnum code, String message) {
        super(message);
        this.code = code.getCode();
        this.msg = message;
        this.value = code.getName();
    }

    public ServiceException(ServiceErrorEnum code, String message, Throwable cause) {
        super(message, cause);
        this.code = code.getCode();
        this.msg = message;
        this.value = code.getName();
    }

    public ServiceException(String code, String message) {
        this.code = code;
        this.msg = message;
    }

    public String getMsg() {
        return msg;
    }

    public String getCode() {
        return code;
    }

    public String getValue() {
        return value;
    }

}
