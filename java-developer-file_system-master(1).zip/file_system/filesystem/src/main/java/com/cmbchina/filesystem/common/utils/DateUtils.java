package com.cmbchina.filesystem.common.utils;

import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.*;

public class DateUtils {
    /**
     * 时间戳转换为字符串
     * @param time
     * @return
     */
    public static Date time2Date(String time) {
        if (StringUtils.isBlank(time)) {
            return null;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(Long.parseLong(time));
        return calendar.getTime();
    }

    public static String time2DateStr(String time) {
        if (StringUtils.isBlank(time)) {
            return null;
        }
        Date date = DateUtils.time2Date(time);
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
    }

    public static String date2Str(Date date) {
        if (date == null) {
            return null;
        }
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
    }

    /**
     * 获取当月的所有日期
     * @return
     */
    public static List<Integer> getDaysByCurrentMonth() {
        Calendar calendar = Calendar.getInstance(Locale.CHINA);
        int maxDate = calendar.getActualMaximum(Calendar.DATE);
        List<Integer> dateList = new ArrayList<>();
        for (int i = 1; i <= maxDate; i++) {
            dateList.add(i);
        }
        return dateList;
    }

}
