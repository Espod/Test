package com.cmbchina.filesystem.dao;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.cmbchina.filesystem.entity.FsFileInfo;

import java.util.List;
import java.util.Map;

/**
 * <p>
  * 文件信息表 Mapper 接口
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
public interface FsFileInfoMapper extends BaseMapper<FsFileInfo> {

    /**
     *
     * 功能描述: 查询当前目录下的子目录
     * @param: [map]
     * @return: java.util.List<java.lang.Integer>
     * @auther: chenxianqiang
     * @date: 2018/12/2 18:14
     */
    List<Integer> listChildrenDirectory(Map<String, Object> map);

    /**
     *
     * 功能描述: 通过ip地址查询允许访问的根目录
     * @param: [ipAddress]
     * @return: java.util.List<com.cmbchina.filesystem.entity.FsFileInfo>
     * @auther: chenxianqiang
     * @date: 2018/12/2 18:54
     */
    List<FsFileInfo> listByIpAddress(String ipAddress);
}