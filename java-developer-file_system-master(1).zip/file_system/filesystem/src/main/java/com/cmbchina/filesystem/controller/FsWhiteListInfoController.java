package com.cmbchina.filesystem.controller;


import com.cmbchina.filesystem.controller.base.TokenController;
import com.cmbchina.filesystem.service.FsWhiteListInfoService;
import com.cmbchina.filesystem.utils.http.RESP;
import com.cmbchina.filesystem.vo.WhiteListInfoVO;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * <p>
 * 白名单信息表 前端控制器
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
@RestController
@RequestMapping("/auth/token/whiteList")
public class FsWhiteListInfoController extends TokenController {

    @Resource
    private FsWhiteListInfoService fsWhiteListInfoService;

    /**
     * 创建白名单
     * @param whiteListInfoVO
     * @return
     */
    @PostMapping("/create")
    public RESP<?> create(@RequestBody WhiteListInfoVO whiteListInfoVO) {
        try {
            fsWhiteListInfoService.batchCreateWhiteList(whiteListInfoVO, getUserId());
            return RESP.respSuccess("新增白名单成功");
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }

    /**
     * 修改白名单信息
     * @param whiteListInfoVO
     * @return
     */
    @PostMapping("/update")
    public RESP<?> update(@RequestBody WhiteListInfoVO whiteListInfoVO) {
        try {
            fsWhiteListInfoService.batchUpdate(whiteListInfoVO, getUserId());
            return RESP.respSuccess("修改白名单成功");
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }

    /**
     * 删除白名单信息
     * @param catalogId
     * @return
     */
    @PostMapping("/delete/{catalogId}")
    public RESP<?> delete(@PathVariable("catalogId") Integer catalogId) {
        try {
            fsWhiteListInfoService.deleteByCatalogId(catalogId);
            return RESP.respSuccess("删除白名单成功");
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }
}
