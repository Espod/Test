package com.cmbchina.filesystem.controller;

import com.cmbchina.filesystem.controller.base.TokenController;
import com.cmbchina.filesystem.service.FsFileInfoService;
import com.cmbchina.filesystem.utils.http.RESP;
import com.cmbchina.filesystem.vo.FileInfoVO;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 文件管理客户端控制器
 */
@RestController
@RequestMapping("/auth/white/client")
public class FsFileClientController extends TokenController {

    @Resource
    private FsFileInfoService fsFileInfoService;

    /**
     * 展示当前目录
     * @param file
     * @return
     */
    @PostMapping("/showCatalog")
    public RESP<?> showCatalog(@RequestBody FileInfoVO file) {
        try {
            List<FileInfoVO> fileInfoVOS = fsFileInfoService.showCurrentCatalog(this.getClientIpAddr(), file.getParentId());
            return RESP.respSuccess("获取信息成功", fileInfoVOS);
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }

    @GetMapping("/download")
    public RESP<?> downLoad(String downLoadId, String fileType, Integer fileId, HttpServletResponse response) {
        try {
            fsFileInfoService.downLoadFile(response, downLoadId, fileType, this.getClientIpAddr(), fileId);
            return null;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return assembleExceptionMessage(e);
        }
    }
}
