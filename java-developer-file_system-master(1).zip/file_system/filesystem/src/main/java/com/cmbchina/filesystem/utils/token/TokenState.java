package com.cmbchina.filesystem.utils.token;

/**
 * @Author yuyang@qxy37.com
 * @Time 2018/9/11 0011 14:31
 */
public enum TokenState {
    VALID,      // 认证通过
    EXPIRED,    //过期Token
    INVALID,     //无效的Token
    USER_NULL,  //用户为空
    PASS_NULL;  //密码为空

    /**
     * 根据字符串state获取TokenState
     *
     * @param state 状态
     * @return
     */
    public static TokenState

    getTokenState(String state) {
        return TokenState.valueOf(state);
    }
}
