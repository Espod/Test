package com.cmbchina.filesystem.common.enums;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/12/1 16:58
 * @Description:
 */
public enum FileEnum {

    FILE(0),DIRECTORY(1);

    private int code;

    FileEnum(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
