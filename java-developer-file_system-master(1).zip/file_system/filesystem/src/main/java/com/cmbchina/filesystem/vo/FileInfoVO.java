package com.cmbchina.filesystem.vo;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;
import java.util.List;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/12/1 16:40
 * @Description:
 */
public class FileInfoVO {

    private Integer id;
    /**
     * 文件名称
     */
    private String fileName;
    /**
     * 文件类型（文件后缀名）
     */
    private String fileType;
    /**
     * 是否是文件夹:0不是，1是
     */
    private Integer isDirectory;
    /**
     * 父级id，默认为0
     */
    private Integer parentId;

    /**
     * 文件大小：单位：kb
     */
    private Long fileSize;
    /**
     * 保存到服务端的下载路径，只有文件才会有路径
     */
    private String downLoadId;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 更新人
     */
    private String updateBy;
    /**
     * 创建时间
     */
    @JsonFormat(timezone = "GMT", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 白名单列表
     */
    private List<WhiteListInfoVO> whiteList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public Integer getIsDirectory() {
        return isDirectory;
    }

    public void setIsDirectory(Integer isDirectory) {
        this.isDirectory = isDirectory;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getDownLoadId() {
        return downLoadId;
    }

    public void setDownLoadId(String downLoadId) {
        this.downLoadId = downLoadId;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    @JsonFormat(timezone = "GMT", pattern = "yyyy-MM-dd HH:mm:ss")
    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public List<WhiteListInfoVO> getWhiteList() {
        return whiteList;
    }

    public void setWhiteList(List<WhiteListInfoVO> whiteList) {
        this.whiteList = whiteList;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }
}
