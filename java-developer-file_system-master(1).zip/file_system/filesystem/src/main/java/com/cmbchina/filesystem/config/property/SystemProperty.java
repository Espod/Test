package com.cmbchina.filesystem.config.property;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * 系统属性文件
 */
@Configuration
@ConfigurationProperties(prefix = "file-system")
public class SystemProperty {

    /**
     * 文件目录前缀
     */
    private String filePrePath;

    public String getFilePrePath() {
        return filePrePath;
    }

    public void setFilePrePath(String filePrePath) {
        this.filePrePath = filePrePath;
    }
}
