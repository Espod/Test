package com.cmbchina.filesystem.service;

import com.cmbchina.filesystem.vo.WhiteListInfoVO;

import java.util.List;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/12/1 16:21
 * @Description:
 */
public interface FsWhiteListInfoService {

    /**
     *
     * 功能描述: 通过ip地址获取白名单信息
     * @param: [ipAddress]
     * @return: com.cmbchina.filesystem.vo.WhiteListInfoVO
     * @auther: chenxianqiang
     * @date: 2018/12/1 14:00
     */
    List<WhiteListInfoVO> getListByIpAddress(String ipAddress) throws Exception;

    /**
     *
     * 功能描述: 批量创建白名单
     * @param: [whiteListInfoVO, createBy]
     * @return: void
     * @auther: chenxianqiang
     * @date: 2018/12/2 18:59
     */
    void batchCreateWhiteList(WhiteListInfoVO whiteListInfoVO, String createBy) throws Exception;

    /**
     *
     * 功能描述: 创建白名单
     * @param: [ipAddress, catalogId, createBy]
     * @return: void
     * @auther: chenxianqiang
     * @date: 2018/12/2 19:10
     */
    void createWhiteList(String ipAddress, Integer catalogId, String createBy) throws Exception;

    /**
     *
     * 功能描述: 批量删除当前目录授权的白名单
     * @param: [whiteListIds]
     * @return: void
     * @auther: chenxianqiang
     * @date: 2018/12/2 19:35
     */
    void batchDeleteWhiteList(String ipAddress, Integer catalogId) throws Exception;

    /**
     *
     * 功能描述: 删除白名单
     * @param: [ipAddress, catalogId]
     * @return: void
     * @auther: chenxianqiang
     * @date: 2018/12/2 19:43
     */
    void deleteWhiteList(String ipAddress, Integer catalogId) throws Exception;

    /**
     *
     * 功能描述: 查询当前目录下授权的所有白名单
     * @param: [catalogId]
     * @return: java.util.List<com.cmbchina.filesystem.vo.WhiteListInfoVO>
     * @auther: chenxianqiang
     * @date: 2018/12/2 20:00
     */
    List<WhiteListInfoVO> getListByCatalogId(Integer catalogId) throws Exception;

    /**
     * 删除白名单
     * @param catalogId
     * @throws Exception
     */
    void deleteByCatalogId(Integer catalogId) throws Exception;

    /**
     * 批量修改白名单
     * 先将该目录下的白名单删除，再新增
     * @throws Exception
     */
    void batchUpdate(WhiteListInfoVO whiteListInfoVO, String updateBy) throws Exception;

}
