package com.cmbchina.filesystem.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.enums.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;
import java.io.Serializable;

/**
 * <p>
 * 白名单信息表
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
@TableName("fs_white_list_info")
public class FsWhiteListInfo extends Model<FsWhiteListInfo> {

    private static final long serialVersionUID = 1L;

	@TableId(value="id", type= IdType.AUTO)
	private Integer id;
    /**
     * 白名单ip地址
     */
	@TableField("ip_address")
	private String ipAddress;
    /**
     * 允许访问的目录id
     */
	@TableField("catalog_id")
	private Integer catalogId;
    /**
     * 创建人
     */
	@TableField("create_by")
	private String createBy;
    /**
     * 更新人
     */
	@TableField("update_by")
	private String updateBy;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
    /**
     * 更新时间
     */
	@TableField("update_time")
	private Date updateTime;


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Integer getCatalogId() {
		return catalogId;
	}

	public void setCatalogId(Integer catalogId) {
		this.catalogId = catalogId;
	}

	public String getCreateBy() {
		return createBy;
	}

	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	public String getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Override
	protected Serializable pkVal() {
		return this.id;
	}

	@Override
	public String toString() {
		return "FsWhiteListInfo{" +
			", id=" + id +
			", ipAddress=" + ipAddress +
			", catalogId=" + catalogId +
			", createBy=" + createBy +
			", updateBy=" + updateBy +
			", createTime=" + createTime +
			", updateTime=" + updateTime +
			"}";
	}
}
