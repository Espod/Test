package com.cmbchina.filesystem.controller;

import com.cmbchina.filesystem.controller.base.TokenController;
import com.cmbchina.filesystem.service.FsManagerInfoService;
import com.cmbchina.filesystem.utils.http.RESP;
import com.cmbchina.filesystem.vo.ManagerInfoVO;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/12/1 15:38
 * @Description:
 */
@RestController
public class LoginController extends TokenController {


    @Resource
    private FsManagerInfoService fsManagerInfoService;

    @PostMapping("/login")
    public RESP<?> login(@RequestBody ManagerInfoVO managerInfoVO) {

        try {

            managerInfoVO = fsManagerInfoService.login(managerInfoVO);
            String token = createToken(managerInfoVO.getAccount());
            managerInfoVO.setToken(token);
        } catch (Exception e) {

            return assembleExceptionMessage(e);
        }

        return RESP.respSuccess("查询成功！", managerInfoVO);
    }
}
