package com.cmbchina.filesystem.config.interceptor;

import com.cmbchina.filesystem.controller.base.TokenController;
import com.cmbchina.filesystem.exception.ServiceException;
import com.cmbchina.filesystem.service.FsWhiteListInfoService;
import com.cmbchina.filesystem.utils.http.RESP;
import com.cmbchina.filesystem.vo.WhiteListInfoVO;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/12/1 18:26
 * @Description: 白名单拦截器
 */
@Component
public class WebAuthedWhiteListInterceptor extends TokenController implements HandlerInterceptor {

    @Resource
    private FsWhiteListInfoService fsWhiteListInfoService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        try {

            if (this.checkWhiteListInfoNotExist()) {
                RESP.responseData(response,RESP.resp(RESP.NOAUTH,"您没有权限访问" + this.getClientIpAddr()));
                return false;
            }
            return true;
        } catch (ServiceException e) {
            RESP.responseData(response,RESP.resp(RESP.TIMEOUT,"服务器发生错误，请稍后再试！"));
            return false;
        }
    }

    /**
     *
     * 功能描述: 检查白名单信息是否不存在
     * @param: [request]
     * @return: boolean
     * @auther: chenxianqiang
     * @date: 2018/12/1 14:18
     */
    private boolean checkWhiteListInfoNotExist() throws Exception {
        String hostAddress = null;
        hostAddress = this.getClientIpAddr();
        System.err.println(hostAddress);
        List<WhiteListInfoVO> list = fsWhiteListInfoService.getListByIpAddress(hostAddress);
        return CollectionUtils.isEmpty(list);
    }
}
