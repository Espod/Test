package com.cmbchina.filesystem;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 *
 * 功能描述:这是一个基于网页的文件管理系统，目前为第一版本，功能简单，后期可以再加
 * 功能1：白名单功能
 * 功能2：文件上传下载功能
 * @auther: chenxianqiang
 * @date: 2018/11/30 15:31
 */
@SpringBootApplication
@EnableTransactionManagement
@MapperScan("com.cmbchina.filesystem.dao")
public class FilesystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(FilesystemApplication.class, args);
    }
}
