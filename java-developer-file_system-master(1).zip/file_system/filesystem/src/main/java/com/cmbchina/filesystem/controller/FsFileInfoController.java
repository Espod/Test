package com.cmbchina.filesystem.controller;


import com.cmbchina.filesystem.controller.base.TokenController;
import com.cmbchina.filesystem.service.FsFileInfoService;
import com.cmbchina.filesystem.utils.http.RESP;
import com.cmbchina.filesystem.vo.FileInfoVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * <p>
 * 文件信息表 前端控制器
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
@RestController
@RequestMapping("/auth/token/file")
public class FsFileInfoController extends TokenController {


    public static Logger logger = LoggerFactory.getLogger(FsFileInfoController.class);

    @Resource
    private FsFileInfoService fsFileInfoService;


    /**
     * 单文件上传
     * @param file
     * @param fileInfoVO
     * @return
     */
    @PostMapping("/upload")
    public RESP<?> upload(@RequestParam("file") MultipartFile file, FileInfoVO fileInfoVO) {
        try {
            fsFileInfoService.createFile(fileInfoVO, getUserId(), file);
            return RESP.respSuccess("上传成功");
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }

    /**
     * 多文件上传
     * @param file
     * @param fileInfoVO
     * @return
     */
    @PostMapping("/batchUpload")
    public RESP<?> batchUpload(@RequestParam("file") MultipartFile[] file, FileInfoVO fileInfoVO) {
        try {
            fsFileInfoService.batchUploadFiles(file, fileInfoVO, getUserId());
            return RESP.respSuccess("上传成功");
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }


    @GetMapping("/download")
    public void downLoad(String downLoadId, String fileType, HttpServletResponse response) {
        try {
            fsFileInfoService.downLoadFile(response, downLoadId, fileType);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    /**
     * 下载文件夹
     * @param parentId
     * @param response
     */
    @GetMapping("/download/directory")
    public void downloadDirectory(Integer parentId, HttpServletResponse response) {
        try {
            fsFileInfoService.zipDirectory(parentId, response);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    /**
     * 打包下载
     * @param parentIds
     * @param response
     */
    @GetMapping("/download/package")
    public void downloadPackage(String parentIds, HttpServletResponse response) {
        try {
            fsFileInfoService.zipPackage(parentIds, response);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }


    /**
     * 展示目录
     *
     * @param file
     * @return
     */
    @PostMapping("/showCatalog")
    public RESP<?> showCatalog(@RequestBody FileInfoVO file) {
        try {
            List<FileInfoVO> fileInfoVOS = fsFileInfoService.showCurrentCatalog(file.getParentId(), getUserId());
            return RESP.respSuccess("获取信息成功", fileInfoVOS);
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }

    /**
     * 新建文件夹
     *
     * @param file
     * @return
     */
    @PostMapping("/createDirectory")
    public RESP<?> createDirectory(@RequestBody FileInfoVO file) {
        try {
            fsFileInfoService.createDirectory(file, getUserId());
            return RESP.respSuccess("新建文件夹成功");
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }

    /**
     * 更新名称
     *
     * @param file
     * @return
     */
    @PostMapping("/updateName")
    public RESP<?> updateName(@RequestBody FileInfoVO file) {
        try {
            fsFileInfoService.updateFileName(file, getUserId());
            return RESP.respSuccess("更新名称成功");
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }

    /**
     * 删除
     * @param id
     * @return
     */
    @PostMapping("/delete/{id}")
    public RESP<?> updateName(@PathVariable Integer id) {
        try {
            fsFileInfoService.deleteFile(id);
            return RESP.respSuccess("删除成功");
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }

    /**
     * 批量删除文件
     * @param ids
     * @return
     */
    @PostMapping("/deleteBatch/{ids}")
    public RESP<?> deleteBatch(@PathVariable String ids) {
        try {
            fsFileInfoService.batchDeleteFiles(ids);
            return RESP.respSuccess("删除成功");
        } catch (Exception e) {
            return assembleExceptionMessage(e);
        }
    }

}
