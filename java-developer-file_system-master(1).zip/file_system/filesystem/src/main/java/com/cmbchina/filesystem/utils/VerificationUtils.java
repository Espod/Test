package com.cmbchina.filesystem.utils;


import com.cmbchina.filesystem.exception.ServiceException;
import com.cmbchina.filesystem.exception.error.ServiceErrorEnum;

import java.util.Collection;

/**
 * 对象验证
 *
 * @Author yuyang@qxy37.com
 * @Time 2018/8/17 0017 13:17
 */
public class VerificationUtils {
    /**
     * 集合为空抛异常
     * @param t
     * @param message
     * @param <T>
     * @throws ServiceException
     */
    public static <T extends Collection> void isCollectionsNull(T t, String message) throws ServiceException {
        if (t == null) {
            throw new ServiceException(ServiceErrorEnum.NULL, message);
        }
    }

    /**
     * 集合为空抛异常
     * @param t
     * @param message
     * @param <T>
     * @throws ServiceException
     */
    public static <T extends Collection> void isCollectionsEmpty(T t, String message) throws ServiceException {
        if (t == null || t.size() == 0) {
            throw new ServiceException(ServiceErrorEnum.NULL, message);
        }
    }

    /**
     * 集合不为空抛异常
     * @param t
     * @param message
     * @param <T>
     * @throws ServiceException
     */
    public static <T extends Collection> void isCollectionsNotEmpty(T t, String message) throws ServiceException {
        if (t == null || t.size() > 0) {
            throw new ServiceException(ServiceErrorEnum.EXIST, message);
        }
    }

    /**
     * 集合不为空抛异常
     * @param t
     * @param message
     * @param <T>
     * @throws ServiceException
     */
    public static <T extends Collection> void isCollectionsNotNull(T t, String message) throws ServiceException {
        if (t == null) {
            throw new ServiceException(ServiceErrorEnum.EXIST, message);
        }
    }

    /**
     * 对象为空
     *
     * @param t   对象类型
     * @param <T> 对象泛型
     * @throws ServiceException 业务异常
     */
    public static <T> boolean isNull(T t) {
        return t == null;
    }

    /**
     * 对象不为空
     *
     * @param t   对象类型
     * @param <T> 对象泛型
     * @throws ServiceException 业务异常
     */
    public static <T> boolean isNotNull(T t) {
        return t != null;
    }

    /**
     * 对象为空抛异常
     *
     * @param t       对象类型
     * @param message 异常信息
     * @param <T>     对象泛型
     * @throws ServiceException 业务异常
     */
    public static <T> void isNull(T t, String message) throws ServiceException {
        if (t == null) {
            throw new ServiceException(ServiceErrorEnum.NULL, message);
        }
    }

    /**
     * 对象不为空
     *
     * @param t   对象类型
     * @param <T> 对象泛型
     * @throws ServiceException 业务异常
     */
    public static <T> void isNotNull(T t, String message) throws ServiceException {
        if (t != null) {
            throw new ServiceException(ServiceErrorEnum.EXIST, message);
        }
    }

    /**
     * 字符串为空抛异常
     *
     * @param str     字符串
     * @param message 异常信息
     * @throws ServiceException 业务异常
     */
    public static void isStringEmpty(String str, String message) throws ServiceException {
        if (str == null || "".equals(str)) {
            throw new ServiceException(ServiceErrorEnum.STRING_EMPTY, message);
        }
    }

    /**
     * 字符串不为空
     *
     * @param str 字符串
     * @return
     */
    public static boolean isStringNotEmpty(String str) {
        return str != null && "".equals(str);
    }

    /**
     * 字符串为空
     *
     * @param str 字符串
     * @return
     */
    public static boolean isStringEmpty(String str) {
        return str == null || "".equals(str);
    }

    /**
     * 删除异常
     *
     * @param status  状态
     * @param message 消息
     * @throws ServiceException 业务异常
     */
    public static void isDelete(String status, String message) throws ServiceException {
        if ("DELETED".equals(status)) {
            throw new ServiceException(ServiceErrorEnum.VALUE_NO_LEGALITY, message);
        }
    }

    /**
     * 未删除异常
     *
     * @param status  状态
     * @param message 消息
     * @throws ServiceException 业务异常
     */
    public static void isNotDelete(String status, String message) throws ServiceException {
        if ("UNDELETE".equals(status)) {
            throw new ServiceException(ServiceErrorEnum.VALUE_NO_LEGALITY, message);
        }
    }

    /**
     * 禁用异常
     *
     * @param status  状态
     * @param message 消息
     * @throws ServiceException 业务异常
     */
    public static void isDisable(String status, String message) throws ServiceException {
        if ("DISABLED".equals(status)) {
            throw new ServiceException(ServiceErrorEnum.VALUE_NO_LEGALITY, message);
        }
    }

    /**
     * 未禁用异常
     *
     * @param status  状态
     * @param message 消息
     * @throws ServiceException 业务异常
     */
    public static void isNotDisable(String status, String message) throws ServiceException {
        if ("UNDISABLE".equals(status)) {
            throw new ServiceException(ServiceErrorEnum.VALUE_NO_LEGALITY, message);
        }
    }
}
