package com.cmbchina.filesystem.service;

import com.cmbchina.filesystem.vo.FileInfoVO;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/12/1 16:39
 * @Description:
 */
public interface FsFileInfoService {

    /**
     *
     * 功能描述: 创建文件夹
     * @param: [fileInfoVO, createBy]
     * @return: void
     * @auther: chenxianqiang
     * @date: 2018/12/1 16:48
     */
    void createDirectory(FileInfoVO fileInfoVO, String createBy) throws Exception;

    /**
     *
     * 功能描述: 创建文件
     * @param: [fileInfoVO, createBy]
     * @return: void
     * @auther: chenxianqiang
     * @date: 2018/12/1 17:03
     */
    void createFile(FileInfoVO fileInfoVO, String createBy, MultipartFile file) throws Exception;

    /**
     *
     * 功能描述: 文件上传
     * @param: [file]
     * @return: java.lang.String
     * @auther: chenxianqiang
     * @date: 2018/12/1 19:20
     */
    FileInfoVO uploadFile(MultipartFile file, String downLoadId) throws Exception;


    /**
     * 批量上传文件夹
     * @param fileList
     * @param fileInfoVO
     * @param createBy
     * @throws Exception
     */
    void batchUploadFiles(MultipartFile[] fileList, FileInfoVO fileInfoVO, String createBy) throws Exception;

    /**
     *
     * 功能描述: 下载文件
     * @param: [fileInfoVO]
     * @return: void
     * @auther: chenxianqiang
     * @date: 2018/12/1 21:29
     */
    void downLoadFile(HttpServletResponse response, String downLoadId, String fileType) throws Exception;


    /**
     * 下载文件
     * @param response
     * @param downLoadId
     * @param fileType
     * @param ipAddress
     * @throws Exception
     */
    void downLoadFile(HttpServletResponse response, String downLoadId, String fileType, String ipAddress, Integer fileId) throws Exception;

    /**
     *
     * 功能描述: 展示当前目录
     * 思路：1.判断parentId是否为空,若为空，再判断账号是否为空，账号也为空的话，再判断ip地址是否为空
     * 2.账号不为空，查询当前账号下的根目录下的所有目录或文件
     * 3.账号为空，ip地址不为空，查询当前白名单表中，当前ip地址下所有允许访问的目录或文件
     * 4.parentId不为空，直接查询文件表中当前parentId下的一级子目录或文件
     * @param: [parentId, account, ipAddress]
     * @return: java.util.List<com.cmbchina.filesystem.vo.FileInfoVO>
     * @auther: chenxianqiang
     * @date: 2018/12/2 11:11
     */
    List<FileInfoVO> showCurrentCatalog(Integer parentId, String account, String ipAddress, boolean showWhiteLst) throws Exception;

    /**
     * 展示当前目录（管理员端）
     * @param parentId
     * @param account
     * @return
     * @throws Exception
     */
    List<FileInfoVO> showCurrentCatalog(Integer parentId, String account) throws Exception;

    /**
     * 展示当前目录（客户端）
     * @param ipAddress
     * @param parentId
     * @return
     * @throws Exception
     */
    List<FileInfoVO> showCurrentCatalog(String ipAddress, Integer parentId) throws Exception;

    /**
     * 修改文件（夹）名称
     * @param fileInfoVO
     * @throws Exception
     */
    void updateFileName(FileInfoVO fileInfoVO, String updateBy) throws Exception;

    /**
     * 删除文件（夹）
     * @param fileId
     * @throws Exception
     */
    void deleteFile(Integer fileId) throws Exception;

    /**
     * 批量删除文件（夹）
     * @param fileIds
     * @throws Exception
     */
    void batchDeleteFiles(String fileIds) throws Exception;

    /**
     * 通过文件夹的id压缩该文件夹
     * @param parentId
     * @throws Exception
     */
    void zipDirectory(Integer parentId, HttpServletResponse response) throws Exception;

    /**
     * 打包下载
     * @param parentIds
     * @param response
     * @throws Exception
     */
    void zipPackage(String parentIds, HttpServletResponse response) throws Exception;

}
