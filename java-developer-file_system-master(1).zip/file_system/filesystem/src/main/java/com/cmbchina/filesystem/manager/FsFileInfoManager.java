package com.cmbchina.filesystem.manager;

import com.baomidou.mybatisplus.service.IService;
import com.cmbchina.filesystem.entity.FsFileInfo;
import com.cmbchina.filesystem.vo.FileInfoVO;

import java.util.List;

/**
 * <p>
 * 文件信息表 服务类
 * </p>
 *
 * @author chenxianqiang
 * @since 2018-12-01
 */
public interface FsFileInfoManager extends IService<FsFileInfo> {


    /**
     *
     * 功能描述: 通过文件名称和父类id查询文件信息
     * @param: [fileName, parentId]
     * @return: com.cmbchina.filesystem.entity.FsFileInfo
     * @auther: chenxianqiang
     * @date: 2018/12/1 16:51
     */
    FsFileInfo getOneByFileNameAndParentId(String fileName, Integer parentId) throws Exception;

    /**
     *
     * 功能描述: 创建文件夹
     * @param: [fileName, parentId, createBy]
     * @return: FsFileInfo
     * @auther: chenxianqiang
     * @date: 2018/12/1 16:57
     */
    FsFileInfo createDirectory(String fileName, Integer parentId, String createBy) throws Exception;

    /**
     *
     * 功能描述: 创建文件
     * @param: [fileInfoVO]
     * @return: void
     * @auther: chenxianqiang
     * @date: 2018/12/1 17:13
     */
    void createFile(FileInfoVO fileInfoVO) throws Exception;

    /**
     *
     * 功能描述: 通过远程文件id和文件类型查询文件信息
     * @param: [downLoadId, fileType]
     * @return: com.cmbchina.filesystem.entity.FsFileInfo
     * @auther: chenxianqiang
     * @date: 2018/12/1 21:34
     */
    FsFileInfo getOneByDownLoadIdAndFileType(String downLoadId, String fileType) throws Exception;

    /**
     *
     * 功能描述: 查询当前账号下的根目录下的所有文件或文件夹
     * @param: [account]
     * @return: java.util.List<com.cmbchina.filesystem.entity.FsFileInfo>
     * @auther: chenxianqiang
     * @date: 2018/12/2 11:35
     */
    List<FsFileInfo> getRootListByAccount(String account) throws Exception;

    /**
     *
     * 功能描述: 查询当前ip地址允许访问的目录或文件
     * @param: [ipAddress]
     * @return: java.util.List<com.cmbchina.filesystem.entity.FsFileInfo>
     * @auther: chenxianqiang
     * @date: 2018/12/2 11:36
     */
    List<FsFileInfo> getListByIpAddress(String ipAddress) throws Exception;

    /**
     *
     * 功能描述: 查询当前目录下的所有一级子目录的文件或文件夹
     * @param: [parentId]
     * @return: java.util.List<com.cmbchina.filesystem.entity.FsFileInfo>
     * @auther: chenxianqiang
     * @date: 2018/12/2 11:37
     */
    List<FsFileInfo> getChildrenListByParentId(Integer parentId) throws Exception;

    /**
     *
     * 功能描述: 获取所有子目录
     * 有内存溢出风险
     * @param: [parentId]
     * @return: java.util.List<java.lang.Integer>
     * @auther: chenxianqiang
     * @date: 2018/12/2 18:07
     */
    List<Integer> getAllChildrenDirectoryIdByParentId(Integer parentId, List<Integer> directoryIdList, boolean isDirectory) throws Exception;

    /**
     *
     * 功能描述: 查询当前ip地址下的当前目录下的子目录
     * @param: [parentId, ipAddress]
     * @return: java.util.List<com.cmbchina.filesystem.vo.FileInfoVO>
     * @auther: chenxianqiang
     * @date: 2018/12/2 18:28
     */
    List<FsFileInfo> getChildrenListByParentIdAndIp(Integer parentId, String ipAddress) throws Exception;

    /**
     *
     * 功能描述: 通过ip地址获取所有允许访问的文件夹或所有目录
     * 有内存溢出风险
     * @param: [ipAddress, isDirectory]
     * @return: java.util.List<com.cmbchina.filesystem.entity.FsFileInfo>
     * @auther: chenxianqiang
     * @date: 2018/12/2 17:58
     */
    List<Integer> getAllChildrenIdByIp(String ipAddress, boolean isDirectory) throws Exception;

    /**
     * 校验当前ip是否可以访问当前目录id
     * 这个方法可以防止查询所有子目录造成内存溢出问题
     * @param ipAddress
     * @param catalogId
     * @return
     * @throws Exception
     */
    boolean checkIpContainsCatalogId(String ipAddress, Integer catalogId) throws Exception;

    /**
     * 通过文件名称和类型查询文件
     * @param fileName
     * @param fileType
     * @return
     * @throws Exception
     */
    FsFileInfo getOneByFileNameAndFileType(String fileName, String fileType) throws Exception;

    /**
     * 更新
     * @param fileInfoVO
     * @throws Exception
     */
    void update(FileInfoVO fileInfoVO, String updateBy) throws Exception;
}
