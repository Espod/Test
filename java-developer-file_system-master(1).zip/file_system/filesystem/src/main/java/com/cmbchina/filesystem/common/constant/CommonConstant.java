package com.cmbchina.filesystem.common.constant;

/**
 * @Auther: chenxianqiang
 * @Date: 2018/12/1 19:22
 * @Description:
 */
public interface CommonConstant {

    String FILE_PRE_PATH = "E://fileTest//";//文件保存的目录
    Integer ROOT_PARENT_ID = 0;// 根目录的parentId为0
}
