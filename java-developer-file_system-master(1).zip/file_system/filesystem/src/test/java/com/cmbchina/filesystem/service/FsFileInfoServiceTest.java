package com.cmbchina.filesystem.service;

import com.cmbchina.filesystem.manager.FsFileInfoManager;
import com.cmbchina.filesystem.utils.JsonUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment= SpringBootTest.WebEnvironment.RANDOM_PORT)
public class FsFileInfoServiceTest {

    @Resource
    private FsFileInfoManager fsFileInfoManager;

    @Test
    public void test() {
        System.out.println("hello");
    }

    @Test
    public void getAllChildrenIdByIpTest() {
        try {
            List<Integer> allChildrenIdByIp = fsFileInfoManager.getAllChildrenIdByIp("192.168.1.1", false);
            System.out.println(JsonUtils.toJson(allChildrenIdByIp));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
