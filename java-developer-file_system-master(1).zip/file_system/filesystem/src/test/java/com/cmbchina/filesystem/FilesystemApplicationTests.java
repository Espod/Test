package com.cmbchina.filesystem;

import com.cmbchina.filesystem.service.FsFileInfoService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FilesystemApplicationTests {

    @Resource
    private FsFileInfoService fsFileInfoService;
    @Test
    public void contextLoads() throws Exception {
        fsFileInfoService.zipDirectory(1547, null);
    }

}
